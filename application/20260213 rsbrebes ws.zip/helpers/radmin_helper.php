<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//======================================= ui
function input_pdselect2($name, $options, $selected = '', $attr = FALSE)
{
    // default attribute
    if ($attr === FALSE) {
        $attr = [];
    }

    // default id = name
    if (!isset($attr['id'])) {
        $attr['id'] = $name;
    }

    // default class select2
    if (!isset($attr['class'])) {
        $attr['class'] = 'form-control select2';
    }
/*    else {
        $attr['class'] .= ' select2';
    }*/

    echo form_dropdown($name, $options, $selected, $attr);
}

/*
// AUTO PLACEHOLDER
$attr = [
    'data-placeholder' => 'Pilih Bulan'
];
input_pdselect2('bulan', $cmd_bulan, '', $attr);

// multi select
$attr = [
    'id' => 'user_multi',
    'multiple' => 'multiple'
];
input_pdselect2('user_id[]', $users, [1,3], $attr);

// ajax select2
$attr = [
    'id' => 'customer',
    'class' => 'form-control select2-ajax',
    'data-url' => site_url('ajax/customer'),
    'data-placeholder' => 'Cari customer'
];
input_pdselect2('customer_id', [], '', $attr);

// DEPENDENT DROPDOWN (PARENT)
$attr = [
    'id' => 'provinsi_id',
    'data-child' => 'kota_id',
    'data-url' => site_url('ajax/get_kota'),
    'onchange' => 'loadKota(this)'
];
input_pdselect2('provinsi', $provinsi, '', $attr);

// DEPENDENT DROPDOWN (CHILD) / ID
$attr = [
    'id' => 'kota_id'
];
input_pdselect2('kota', [], '', $attr);

// FILTER LAPORAN (AUTO SUBMIT)
$attr = [
    'id' => 'tahun',
    'onchange' => 'filterLaporan()'
];
input_pdselect2('tahun', $cmd_tahun, date('Y'), $attr);

// DISABLED / READONLY / REQUIRED
$attr = [
    'id' => 'status',
    'disabled' => 'disabled',
    'required' => 'required'
];
input_pdselect2('status', $status, '1', $attr);

// CUSTOM CLASS
$attr = [
    'class' => 'form-control select2 select-sm'
];
input_pdselect2('bank', $bank, '', $attr);

----------------------- JS GLOBAL (SATU KALI SAJA) ----------------
<script>
$('.select2').select2({
    width: '100%',
    placeholder: function(){
        return $(this).data('placeholder') || 'Pilih data';
    },
    allowClear: true
});

$('.select2-ajax').each(function(){
    let el = $(this);
    el.select2({
        ajax: {
            url: el.data('url'),
            dataType: 'json',
            delay: 250,
            data: params => ({ q: params.term }),
            processResults: data => ({ results: data })
        },
        placeholder: el.data('placeholder'),
        allowClear: true
    });
});
</script>

1️⃣ AUTO-INIT JS PAKAI DATA-ATTRIBUTE (ZERO CONFIG JS)

🎯 Tujuan
- Tidak perlu JS per dropdown
- Semua behavior dikontrol lewat HTML attribute
- 1 JS global untuk semua halaman

✅ DATA-ATTRIBUTE STANDARD
-------------------------------------------
| Attribute            | Fungsi           |
| -------------------- | ---------------- |
| `data-select2`       | aktifkan select2 |
| `data-placeholder`   | placeholder      |
| `data-ajax-url`      | AJAX endpoint    |
| `data-parent`        | parent ID        |
| `data-child`         | child ID         |
| `data-tags`          | tagging          |
| `data-minimum-input` | min search       |
| `multiple`           | multi select     |
-------------------------------------------

🔹 JS GLOBAL (SATU FILE)
<script>
$(document).ready(function(){

    $('[data-select2]').each(function(){
        let el = $(this);

        let config = {
            width: '100%',
            placeholder: el.data('placeholder') || 'Pilih data',
            allowClear: true
        };

        // AJAX Select2
        if (el.data('ajax-url')) {
            config.ajax = {
                url: el.data('ajax-url'),
                dataType: 'json',
                delay: 250,
                data: params => ({ q: params.term }),
                processResults: data => ({ results: data }),
                cache: true
            };
            config.minimumInputLength = el.data('minimum-input') || 1;
        }

        // TAGGING
        if (el.data('tags')) {
            config.tags = true;
            config.tokenSeparators = [','];
        }

        el.select2(config);
    });

    // DEPENDENT DROPDOWN
    $('[data-parent]').on('change', function(){
        let parent = $(this);
        let child  = $('#' + parent.data('child'));

        $.post(parent.data('ajax-url'), { id: parent.val() }, function(res){
            child.html(res).trigger('change');
        });
    });

});
</script>

🔹 HELPER KHUSUS SELECT2 TAGGING
   Tanpa helper baru, cukup attr

$attr = [
    'data-select2' => '1',
    'data-tags' => '1',
    'data-placeholder' => 'Tambah tag'
];
input_pdselect2('tags[]', [], [], $attr);

✔ bisa input manual
✔ bisa multi value
✔ cocok untuk kategori, keyword, label
*/
function selectra(
    $name,
    $options = [],
    $selected = '',
    $empty_text = '-- Pilih Data --',
    $attr = []
) 
{
    if (!is_array($options)) {
        $options = [];
    }

    // default attribute
    $attr['name']  = $name;
    $attr['id']    = $attr['id']    ?? $name;
    $attr['class'] = $attr['class'] ?? 'form-control select2';

    echo '<select';
    foreach ($attr as $k => $v) {
        echo ' '.$k.'="'.$v.'"';
    }
    echo '>';

    // option empty / 0
    if ($empty_text !== FALSE) {
        echo '<option value="0">'.$empty_text.'</option>';
    }

    // looping data
    foreach ($options as $key => $val) {
        $is_selected = ($key == $selected) ? 'selected' : '';
        echo '<option value="'.$key.'" '.$is_selected.'>'.$val.'</option>';
    }

    echo '</select>';
}

function selectracanmulti(
    $name,
    $options = [],        // array data dari db
    $selected = '',       // value default selected
    $empty_text = '-- Pilih Data --',
    $attr = [],
    $value_field = 'id'   // field yang ingin dijadikan <option value="">
) {
    if (!is_array($options)) {
        $options = [];
    }

    $attr['name']  = $name;
    $attr['id']    = $attr['id'] ?? $name;
    $attr['class'] = $attr['class'] ?? 'form-control select2';

    // multiple support
    $is_multiple = isset($attr['multiple']) && ($attr['multiple'] === true || $attr['multiple'] === 'multiple');
    if ($is_multiple && substr($attr['name'],-2)!=='[]') {
        $attr['name'] .= '[]';
    }

    // set_value auto
    $ci = &get_instance();
    if ($is_multiple) {
        $selected_values = set_value($name, $selected);
        if (!is_array($selected_values)) {
            $selected_values = [$selected_values];
        }
    } else {
        $selected_values = [set_value($name, $selected)];
    }

    echo '<select';
    foreach ($attr as $k=>$v) {
        if (is_bool($v) && $v===true) echo ' '.$k;
        else echo ' '.$k.'="'.$v.'"';
    }
    echo '>';

    if ($empty_text!==FALSE && !$is_multiple) {
        echo '<option value="0">'.$empty_text.'</option>';
    }

    // looping options
    foreach ($options as $row) {
        $value = isset($row[$value_field]) ? $row[$value_field] : '';
        $label = $row['nama'] ?? $row['name'] ?? $value;

        $is_selected = in_array((string)$value,array_map('strval',$selected_values)) ? 'selected' : '';
        echo '<option value="'.$value.'" '.$is_selected.'>'.$label.'</option>';
    }

    echo '</select>';
}

/*
selectra(
    'id_status_pegawai',
    $tipe_pegawai,   // dari model
    $selected_id,    // value terpilih
    'Pilih Status Pegawai'
);
selectra(
    'id_status_pegawai',
    $tipe_pegawai,
    $selected_id,
    FALSE
);
selectra(
    'id_status_pegawai',
    $tipe_pegawai,
    $selected_id,
    'Pilih Status Pegawai',
    [
        'required' => 'required',
        'data-placeholder' => 'Pilih Status'
    ]
);
// attr selectra bisa juga buat selectracanmulti
selectracanmulti(
    'hobi',
    ['1' => 'Menyanyi', '2' => 'Menari', '3' => 'Melukis'],
    ['1','3'],        // selected
    FALSE,            // tanpa empty option
    ['multiple' => true],
    'id_pegawai'    // gunakan id_pegawai sebagai value
);

$selected = ['1','3','5'];
selectracanmulti(
    'hobi',
    $hobi,
    $selected,        // selected
    FALSE,            // tanpa empty option
    ['multiple' => true],
    'id_hobi'    // gunakan id_pegawai sebagai value
);
*/

function inputra($name, $value = '', $attr = [])
{
    if ($attr === FALSE || !is_array($attr)) {
        $attr = [];
    }

    // ambil type dulu
    $type = $attr['type'] ?? 'text';
    unset($attr['type']); // type TIDAK boleh ikut ke textarea

    // mandatory
    $attr['name'] = $name;

    // default id
    if (!isset($attr['id'])) {
        $attr['id'] = $name;
    }

    // default class
    if (!isset($attr['class'])) {
        $attr['class'] = 'form-control';
    }

    // textarea
    if ($type === 'textarea') {
        return form_textarea($attr, set_value($name, $value));
    }

    // input biasa
    $attr['type']  = $type;
    $attr['value'] = set_value($name, $value);

    echo form_input($attr);
}
/*
Paling simpel
echo inputra('nama_pegawai', $nama_pegawai);

Override class & tambah atribut lain
echo inputra('nama_pegawai', $nama_pegawai, [
    'maxlength'   => 60,
    'autofocus'   => true,
    'required'    => true,
    'placeholder' => 'Nama Pegawai'
]);
echo inputra('email', $email, [
    'type'  => 'email',
    'class' => 'form-control is-valid'
]);
*/
/*

 // WRAPPER FUNCTIONS

function input_pdhidden($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'hidden';
    input_pd($name, $value, $attr);
}

function input_pdnumber($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'number';
    input_pd($name, $value, $attr);
}

function input_pdemail($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'email';
    input_pd($name, $value, $attr);
}

function input_pdpassword($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'password';
    input_pd($name, $value, $attr);
}

function input_pdfile($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'file';
    input_pd($name, $value, $attr);
}

function input_pddate($name, $value = '', $attr = FALSE)
{
    if ($attr === FALSE) $attr = [];

    $attr['type'] = 'text';

    if (!isset($attr['class'])) {
        $attr['class'] = 'form-control basic-date';
    } else {
        $attr['class'] .= ' basic-date';
    }

    if (!isset($attr['placeholder'])) {
        $attr['placeholder'] = 'YYYY-MM-DD';
    }

    input_pd($name, $value, $attr);
}

function input_pdtime($name, $value = '', $attr = FALSE)
{
    if ($attr === FALSE) $attr = [];

    $attr['type'] = 'text';

    if (!isset($attr['class'])) {
        $attr['class'] = 'form-control date-time-picker';
    } else {
        $attr['class'] .= ' date-time-picker';
    }

    if (!isset($attr['placeholder'])) {
        $attr['placeholder'] = '12:00';
    }

    input_pd($name, $value, $attr);
}

function input_pdtextarea($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'textarea';
    input_pd($name, $value, $attr);
}

function input_pdtel($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'tel';
    input_pd($name, $value, $attr);
}

function input_pdsearch($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'search';
    input_pd($name, $value, $attr);
}

function input_pdurl($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'url';
    input_pd($name, $value, $attr);
}

function input_pdcolor($name, $value = '', $attr = FALSE)
{
    $attr['type'] = 'color';
    input_pd($name, $value, $attr);
}

// =================================== contoh
Hidden
<?php input_pdhidden('id_user', $id_user); ?>

Number
<?php input_pdnumber('umur', $umur, [
    'min' => 0,
    'max' => 100
]); ?>

Email
<?php input_pdemail('email', $email, [
    'placeholder' => 'Email'
]); ?>

Password
<?php input_pdpassword('password', '', [
    'placeholder' => 'Password'
]); ?>

Date
<?php input_pddate('tgl_lahir', $tgl_lahir); ?>

Time
<?php input_pdtime('jam_mulai', $jam_mulai); ?>

Textarea
<?php input_pdtextarea('alamat', $alamat, [
    'rows' => 5,
    'placeholder' => 'Alamat lengkap'
]); ?>

Tel (No HP)
<?php input_pdtel('no_hp', $no_hp, [
    'placeholder' => '08xxxxxxxxxx'
]); ?>

Search
<?php input_pdsearch('keyword', '', [
    'placeholder' => 'Cari data...'
]); ?>

URL
<?php input_pdurl('website', $website, [
    'placeholder' => 'https://example.com'
]); ?>

Color
<?php input_pdcolor('warna', $warna ?? '#000000'); ?>
*/
//======================================= helper
/**
 * Helper universal untuk validasi field unik
 *
 * @param string $table      Nama tabel
 * @param array  $fields     Array field => value
 * @param bool   $return_html True = echo HTML langsung, false = return JSON
 */
function check_unique_field($table, $fields = [], $return_html = true)
{
    $ci = &get_instance();

    if (empty($fields) || !is_array($fields)) {
        $res = ['status' => 'error', 'message' => 'Data tidak valid.'];
    } else {
        $ci->db->from($table);
        $ci->db->where($fields);
        $count = (int) $ci->db->count_all_results();

        if ($count === 0) {
            $res = ['status' => 'success', 'message' => 'Data tersedia.'];
        } else {
            $res = ['status' => 'taken', 'message' => 'Data sudah ada.'];
        }
    }

    if ($return_html) {
        $color = $res['status'] === 'success' ? 'green' : 'red';
        echo "<span style='color:$color'>{$res['message']}</span>";
    } else {
        echo json_encode($res);
    }
}

if (!function_exists('swal_flashdata')) {
    /**
     * Menampilkan SweetAlert2 dari flashdata
     */
    function swal_flashdata($session = null)
    {
        $CI = get_instance();
        if (!$session) $session = $CI->session;

        $script = '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>' . PHP_EOL;
        $script .= '<script>document.addEventListener("DOMContentLoaded", function() {' . PHP_EOL;

        $alerts = [];

        // cek flashdata swal
        $custom = $session->flashdata('swal');
        if ($custom) {
            if (is_array($custom) && isset($custom[0])) {
                // multiple alerts
                foreach ($custom as $c) {
                    $alerts[] = [
                        'toast' => $c['toast'] ?? false,
                        'position' => ($c['toast'] ?? false) ? 'top-end' : 'center',
                        'icon'  => $c['status'] ?? 'info',
                        'title' => $c['title'] ?? '',
                        'text'  => $c['message'] ?? '',
                        'timer' => $c['timer'] ?? 2000,
                        'showConfirmButton' => ($c['toast'] ?? false) ? false : true
                    ];
                }
            } else {
                // single alert
                $alerts[] = [
                    'toast' => $custom['toast'] ?? false,
                    'position' => ($custom['toast'] ?? false) ? 'top-end' : 'center',
                    'icon'  => $custom['status'] ?? 'info',
                    'title' => $custom['title'] ?? '',
                    'text'  => $custom['message'] ?? '',
                    'timer' => $custom['timer'] ?? 2000,
                    'showConfirmButton' => ($custom['toast'] ?? false) ? false : true
                ];
            }
        }

        if (!empty($alerts)) {
            $script .= "let swalQueue = ".json_encode($alerts).";" . PHP_EOL;
            $script .= "
                (async function() {
                    for (let a of swalQueue) {
                        await Swal.fire(a);
                    }
                })();
            ";
        }

        $script .= '});</script>' . PHP_EOL;
        return $script;
    }
}

if (!function_exists('swal_response')) {
    /**
     * Response Swal untuk AJAX / NON-AJAX
     */
    function swal_response($params = [])
    {
        $CI =& get_instance();

        $payload = array_merge([
            'status'   => 'info',
            'title'    => '',
            'message'  => '',
            'toast'    => false,
            'timer'    => 2000,
            'reload'   => false,
            'redirect' => null,
            'data'     => null,
        ], $params);

        if ($CI->input->is_ajax_request()) {
            $CI->output
               ->set_content_type('application/json')
               ->set_output(json_encode($payload))
               ->_display();
            exit;
        }

        // fallback NON-AJAX
        $CI->session->set_flashdata('swal', $payload);
        if ($payload['redirect']) redirect($payload['redirect']);
    }
}



/*
js
$.post(url, data, function(res){

    Swal.fire({
        icon: res.status,
        title: res.title,
        text: res.message
    }).then(() => {
        if(res.reload) location.reload();
        if(res.redirect) window.location.href = res.redirect;
    });

}, 'json');
Swal.fire({
    icon: 'warning',
    title: 'Yakin?',
    text: 'Data akan dihapus permanen',
    showCancelButton: true,
    confirmButtonText: 'Ya, hapus!',
    cancelButtonText: 'Batal'
}).then((result) => {
    if(result.isConfirmed){
        // lanjut ajax delete
    }
});

controller
swal_response([
    'status'   => 'success',
    'title'    => 'Berhasil',
    'message'  => 'Data berhasil disimpan',
    'redirect' => base_url('ol_logbook/logbook')
]);
swal_response([
    'status'  => 'success',
    'title'   => 'Berhasil',
    'message' => 'Data berhasil dihapus',
    'reload'  => true
]);
swal_response([
    'status'  => 'warning',
    'title'   => 'Yakin?',
    'message' => 'Data akan dihapus permanen'
]);
swal_response([
    'status'  => 'warning',
    'title'   => 'Perhatian',
    'message' => 'Data sudah terdaftar'
]);
$this->session->set_flashdata('swal', [
    [
        'status' => 'success',
        'title'  => 'Berhasil',
        'message'=> 'Data utama tersimpan'
    ],
    [
        'status' => 'info',
        'title'  => 'Informasi',
        'message'=> 'Silakan lengkapi detail data'
    ]
]);

redirect(base_url('master/data'));
swal_response([
    'status'  => 'success',
    'title'   => 'Berhasil',
    'message' => 'Data berhasil disimpan',
    'reload'  => true
]);


*/