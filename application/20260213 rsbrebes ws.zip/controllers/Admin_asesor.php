<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Makassar');
// ALTER TABLE `ol_user` ADD `status_asesor` TINYINT UNSIGNED NOT NULL DEFAULT '0' AFTER `status_user`;
class Admin_asesor extends CI_controller
{
// -----------------------------------------------------------START-----------------------------------------
  public function __construct(){
          parent::__construct();
          $this->load->model('m_ol_rancak');
          $this->load->model('m_admin_asesor');
           $this->load->model('m_auth');
          $this->m_auth->login_kah();
  }
	function index(){
		$this->pengajuan_kompetensi();
	}
	function pengajuan_kompetensi($mode='view'){
		$data['page']="pengajuan_kompetensi"; 
		$data['header'] = "DATA PENGAJUAN KOMPETENSI";
		$data['title'] = "DATA PENGAJUAN KOMPETENSI";
		$data['link_awal'] = base_url($this->session->beranda);
		$pegawai=$this->m_ol_rancak->ambil_user_pegawai($this->session->id_user);
//		$program = $this->m_umum->ambil_data('a_program','id_program',10);
		$instansi = $this->m_umum->ambil_data('a_instansi','id_instansi',1);
		$stpeg = $this->m_umum->ambil_data('a_online','kode_online','ol_status_pegawai');
		$jabatanekuh = $this->m_umum->ambil_data('jabatan','id_jabatan',$this->session->id_jabatan);
		$data['aran_jabatan'] = $jabatanekuh["nama_jabatan"];
		$data['instance_id'] = $instansi["id_instansi"];
		$data['instance_name'] = $instansi["nama_instansi"];
		$data['idescription'] = $instansi["description"];
		$data['ikeywords'] = $instansi["keywords"];
		$data['iheader'] = $instansi["header"];
		$data['iheader_mini'] = $instansi["header_mini"];
		$data['ifooter'] = $instansi["footer"];
		$data['ilicensed'] = $instansi["licensed"];
		$data['member_id'] = $pegawai["id_pegawai"];
		$data['member_name'] = $pegawai["nama_pegawai"];
		$data['level_name'] = $pegawai["nama_level"];
		$data['photo'] = $pegawai["foto"];
		$asesor = $this->m_umum->ambil_data('kol_komite','id_komite',$this->session->status_asesor);
//		$data['id']   = $this->uri->segment(4, 0);
		//======================= IMPORTANT =========================================
    $data['id']   = urldecode(trim($this->uri->segment(4, 0)));
    $data['id2']   = $this->uri->segment(5, 0);
		$replace_keyword   = preg_replace('/\s+/', ' ', $data['id']);
		$data['key'] = str_replace(' ', '-', $replace_keyword);
		if($data['key'] == NULL OR empty($data['key'])){
			$data['key'] = "";
		}
		if($mode=='view'){
		$this->tampil($data);
		$action = $this->input->post('action');
			if($action == 'BtnProses') {
        $trim_keyword   = urldecode(trim($this->input->post("key")));
  			$replace_keyword   = preg_replace('/\s+/', ' ', $trim_keyword);
  			$key = str_replace(' ', '-', $replace_keyword);
				redirect(base_url('admin_asesor/pengajuan_kompetensi/view/'.$key));
			}
		}
    else if($mode=='data'){
			$key = urldecode(trim($this->uri->segment(4, 0)));
			$key = strtolower($key);
			$key = preg_replace('/[^A-Za-z0-9\-]/', '', $key);
			$key = str_replace(' ', '-', $key);
			echo json_encode($this->m_admin_asesor->pengajuan_kompetensi_all($key));
		}
		else if($mode=='nkr_validator'){
			echo json_encode($this->m_admin_asesor->nkr_pengajuan_validator_tabel($data['key']));
		}
		else{
			if($mode=='pilih'){
			  $data['page'] =  $data['page']."_pilih";		
				$take = $this->m_umum->ambil_data('ol_pengajuan','barcode_pengajuan',$data['key']);
				$kondisi = array('barcode_pegawai'=>$take['barcode_pegawai']);
				$kondisinkr = array('barcode_pengajuan'=>$data['key']);
				$jfe = $this->m_umum->ambil_data_kondisi_2tabel_row('ol_pegawai',$kondisi,'jabatan_fungsional','id_jabatan_fungsional');		
				$data['nkrpengva'] = $this->m_umum->ambil_data_kondisi_result('nkr_pengajuan_validator',$kondisinkr);		
				$data['struktur'] = $this->m_admin_asesor->ambil_data_asesor_no_null();	
				$data['barcode_pengajuan']  = set_value('barcode_pengajuan',$take['barcode_pengajuan']);
				$data['id_pengajuan']  = set_value('id_pengajuan',$take['id_pengajuan']);
				$data['status_pengajuan']  = set_value('status_pengajuan',$take['status_pengajuan']);
				$this->load->view("admin_asesor/isi",$data);
			}
			if($mode=='simpan_pilih'){
				$status_pengajuan = $this->input->post('status_pengajuan');
				if($status_pengajuan == 1){
			  	$this->m_admin_asesor->simpan_pegawai_pengajuan();
					$this->session->set_flashdata('sukses', 'Data Berhasil Di Simpan');
					redirect(base_url('admin_asesor/pengajuan_kompetensi'));
				}else{
					$this->session->set_flashdata('danger', 'Kompetensi Sudah Selesai');
					redirect(base_url('admin_asesor/pengajuan_kompetensi'));
				}
			}
			if($mode=='form'){
				$data['page'] =  $data['page']."_form";
					if(empty($data['key'])){
						redirect(base_url('admin_asesor/pengajuan_kompetensi'));	
					}else{
						$this->tampil($data);	
					}										
			}
			if($mode=='pilih_form'){
			  $data['page'] =  $data['page']."_pilih_form";	
				$kondisi=array('barcode_pengajuan_validator'=>$data['key']);	
				$take = $this->m_umum->ambil_data_kondisi_2tabel_row('nkr_pengajuan_validator',$kondisi,'ol_pengajuan','barcode_pengajuan');		
				$data['form'] = $this->m_admin_asesor->ambil_data_nkr_form($take['kode_unit_pengajuan'],$take['id_instansi']);	
				$data['barcode_pengajuan_validator']  = set_value('barcode_pengajuan_validator',$take['barcode_pengajuan_validator']);
				$data['id_pengajuan_validator']  = set_value('id_pengajuan_validator',$take['id_pengajuan_validator']);
				$data['barcode_pengajuan']  = set_value('barcode_pengajuan',$take['barcode_pengajuan']);
				$data['status_pengajuan']  = set_value('status_pengajuan',$take['status_pengajuan']);
				$data['nkr_form']  = set_value('nkr_form',$take['nkr_form']);
				$this->load->view("admin_asesor/isi",$data);
			}
			if($mode=='simpan_pilih_form'){
				$status_pengajuan = $this->input->post('status_pengajuan');
				$barcode_pengajuan = $this->input->post('barcode_pengajuan');
				if($status_pengajuan == 1){
			  	$this->m_admin_asesor->simpan_form_pengajuan_validator();
					$this->session->set_flashdata('sukses', 'Data Berhasil Di Simpan');
					redirect(base_url('admin_asesor/pengajuan_kompetensi/form/'.$barcode_pengajuan));					
				}else{
					$this->session->set_flashdata('danger', 'Kompetensi Sudah Selesai');
					redirect(base_url('admin_asesor/pengajuan_kompetensi/form/'.$barcode_pengajuan));	
				}
			}
			if($mode=='seting'){
				$data['page'] =  $data['page']."_seting";
					if(empty($data['id'])){
						redirect(base_url('admin_asesor/pengajuan_kompetensi'));	
					}else{
						$this->tampil($data);	
					}										
			}
    if($mode=='selesai'){
     if($this->m_admin_asesor->seting_status_pengajuan($data['id'],$data['id2'])){
     $this->session->set_flashdata('sukses', 'Data Sudah Final');
     redirect(base_url('admin_asesor/pengajuan_rkk'));
     }else{
     $this->session->set_flashdata('danger', 'Masalah Final Data');
     redirect(base_url('admin_asesor/pengajuan_rkk'));
     }
    }
			if($mode=='lihat_form'){
			  $data['page'] =  $data['page']."_lihat_form";	
				$kondisi=array('barcode_pengajuan_validator'=>$data['key']);	
				$take = $this->m_umum->ambil_data_kondisi_2tabel_row('nkr_pengajuan_validator',$kondisi,'ol_pengajuan','barcode_pengajuan');		
				$data['form'] = $this->m_admin_asesor->ambil_data_nkr_form($take['kode_unit_pengajuan'],$take['id_instansi']);	
				$data['barcode_pengajuan_validator']  = set_value('barcode_pengajuan_validator',$take['barcode_pengajuan_validator']);
				$data['id_pengajuan_validator']  = set_value('id_pengajuan_validator',$take['id_pengajuan_validator']);
				$data['barcode_pengajuan']  = set_value('barcode_pengajuan',$take['barcode_pengajuan']);
				$data['status_pengajuan']  = set_value('status_pengajuan',$take['status_pengajuan']);
				$data['nkr_form']  = set_value('nkr_form',$take['nkr_form']);
				$this->load->view("admin_asesor/isi",$data);
			}
			if($mode=='simpan_lihat_form'){
				$status_pengajuan = $this->input->post('status_pengajuan');
				$barcode_pengajuan = $this->input->post('barcode_pengajuan');
				if($status_pengajuan == 1){
			  	$this->m_admin_asesor->simpan_form_pengajuan_validator();
					$this->session->set_flashdata('sukses', 'Data Berhasil Di Simpan');
					redirect(base_url('admin_asesor/pengajuan_kompetensi/form/'.$barcode_pengajuan));					
				}else{
					$this->session->set_flashdata('danger', 'Kompetensi Sudah Selesai');
					redirect(base_url('admin_asesor/pengajuan_kompetensi/form/'.$barcode_pengajuan));	
				}
			}
		}
	}
	function pengajuan_rkk($mode='view'){
		$data['page']="pengajuan_rkk"; 
		$data['header'] = "DATA PENGAJUAN RKK";
		$data['title'] = "DATA PENGAJUAN RKK";
		$data['link_awal'] = base_url($this->session->beranda);
		$pegawai=$this->m_ol_rancak->ambil_user_pegawai($this->session->id_user);
		$instansi = $this->m_umum->ambil_data('a_instansi','id_instansi',1);
		$stpeg = $this->m_umum->ambil_data('a_online','kode_online','ol_status_pegawai');
		$jabatanekuh = $this->m_umum->ambil_data('jabatan','id_jabatan',$this->session->id_jabatan);
		$data['aran_jabatan'] = $jabatanekuh["nama_jabatan"];
		$data['instance_id'] = $instansi["id_instansi"];
		$data['instance_name'] = $instansi["nama_instansi"];
		$data['idescription'] = $instansi["description"];
		$data['ikeywords'] = $instansi["keywords"];
		$data['iheader'] = $instansi["header"];
		$data['iheader_mini'] = $instansi["header_mini"];
		$data['ifooter'] = $instansi["footer"];
		$data['ilicensed'] = $instansi["licensed"];
		$data['member_id'] = $pegawai["id_pegawai"];
		$data['member_name'] = $pegawai["nama_pegawai"];
		$data['level_name'] = $pegawai["nama_level"];
		$data['photo'] = $pegawai["foto"];
		$asesor = $this->m_umum->ambil_data('kol_komite','id_komite',$this->session->status_asesor);
		$data['id']   = $this->uri->segment(4, 0);
  $data['id2']   = $this->uri->segment(5, 0);
		//======================= IMPORTANT =========================================
   if($mode=='view'){
   	$this->tampil($data);
   }
   else if($mode=='data'){
     echo json_encode($this->m_admin_asesor->pengajuan_rkk_all());
   }else{
     $data['yatidak'] = $this->m_rancak->cmd_ya_tidak();
     $data['gambar'] = $this->m_ol_rancak->cmd_gambar_kop();
     $data['struktur'] = $this->m_admin_asesor->ambil_data_asesor_no_null();
     if($mode=='tambah_sign'){
       $data['page'] =  $data['page']."_tambah_sign"; 
       $ambil_pengajuan = $this->m_umum->ambil_data('ol_pengajuan','barcode_pengajuan',$data['id']);
       $knds = array('barcode_pegawai'=>$ambil_pengajuan['barcode_pegawai']);
       $ambil_kw = $this->m_umum->ambil_order_kondisi_2tabel_result('ol_rkk',$knds,'nkr_kewenangan','id_kewenangan','nama_kewenangan','ASC');
       $arr = [];
       foreach($ambil_kw as $val){
           $arr[] = $val['coun_kewenangan'];
       }
       $data['eimplo'] = implode(",", $arr);
       $data['lampiran']  = set_value('lampiran',$this->input->post('lampiran'));
       $data['kop_signature']  = set_value('kop_signature',$this->input->post('kop_signature'));
       $data['no']  = set_value('no',$this->input->post('no'));
       $data['tanggal']  = set_value('tanggal',$this->input->post('tanggal'));
       $data['id_gambar']  = set_value('id_gambar',$this->input->post('id_gambar'));
       $data['header']  = set_value('header',$this->input->post('header'));
       $data['sub_header']  = set_value('sub_header',$this->input->post('sub_header'));
       $data['sub_sub_header']  = set_value('sub_sub_header',$this->input->post('sub_sub_header'));
       $data['sebelum']  = set_value('sebelum',$this->input->post('sebelum'));
       $data['sesudah']  = set_value('sesudah',$this->input->post('sesudah'));
       $data['kanan_tgl']  = set_value('kanan_tgl',$this->input->post('kanan_tgl'));
       $data['tengah_tgl']  = set_value('tengah_tgl',$this->input->post('tengah_tgl'));
       $data['kiri_tgl']  = set_value('kiri_tgl',$this->input->post('kiri_tgl'));
       $data['kanan_top']  = set_value('kanan_top',$this->input->post('kanan_top'));
       $data['kanan_middle']  = set_value('kanan_middle',$this->input->post('kanan_middle'));
       $data['kanan_nama']  = set_value('kanan_nama',$this->input->post('kanan_nama'));
       $data['kanan_nip']  = set_value('kanan_nip',$this->input->post('kanan_nip'));
       $data['tengah_top']  = set_value('tengah_top',$this->input->post('tengah_top'));
       $data['tengah_middle']  = set_value('tengah_middle',$this->input->post('tengah_middle'));
       $data['tengah_nama']  = set_value('tengah_nama',$this->input->post('tengah_nama'));
       $data['tengah_nip']  = set_value('tengah_nip',$this->input->post('tengah_nip'));
       $data['kiri_top']  = set_value('kiri_top',$this->input->post('kiri_top'));
       $data['kiri_middle']  = set_value('kiri_middle',$this->input->post('kiri_middle'));
       $data['kiri_nama']  = set_value('kiri_nama',$this->input->post('kiri_nama'));
       $data['kiri_nip']  = set_value('kiri_nip',$this->input->post('kiri_nip'));
       $data['kiri_signature']  = set_value('kiri_signature',0);
       $data['tengah_signature']  = set_value('tengah_signature',0);
       $data['kanan_signature']  = set_value('kanan_signature',0);
       $this->load->view("admin_asesor/isi",$data);
     }
     if($mode=='simpan_tambah_sign'){
      $status_pengajuan = $this->input->post('status_pengajuan');
      $barcode_pengajuan = $this->input->post('barcode_pengajuan');
      $knds = array('barcode_pengajuan'=>$barcode_pengajuan);
      $jml = $this->m_umum->jumlah_record_filter('ol_rkk',$knds);
      if($jml == 0){
        $this->session->set_flashdata('danger', 'Data Validasi Belum Ada');
        redirect(base_url('admin_asesor/pengajuan_kompetensi'));
      }else{
       if($this->m_admin_asesor->seting_status_pengajuan($barcode_pengajuan,$status_pengajuan)){
        $this->m_admin_asesor->simpan_signature();
        $this->session->set_flashdata('sukses', 'Data Berhasil Di Buat');
        redirect(base_url('admin_asesor/pengajuan_rkk'));
       }else{
        $this->session->set_flashdata('danger', 'Ada Kesalahan Edit Data');
        redirect(base_url('admin_asesor/pengajuan_rkk'));
       }     
      }
     }
    if($mode=='tambah_kewenangan'){
     $data['page'] =  $data['page']."_tambah_kewenangan";
     $kondisinkr = array('id_signature'=>$data['id']);  
     $data['nkrpengva'] = $this->m_umum->ambil_data_kondisi_2tabel_row('ol_pengajuan_signature',$kondisinkr,'ol_pengajuan','barcode_pengajuan');
     $data['status_pengajuan'] = $data['nkrpengva']['status_pengajuan'];
     $data['barcode_pengajuan'] = $data['nkrpengva']['barcode_pengajuan'];

     $knds_peg = array('barcode_pegawai'=>$data['nkrpengva']['barcode_pegawai']);  
     $data['ambil_peg'] = $this->m_umum->ambil_data_kondisi('ol_pegawai',$knds_peg);

     $jabfung = $this->m_umum->ambil_data('jabatan_fungsional','id_jabatan_fungsional',$data['ambil_peg']['id_jabatan_fungsional']);

     $knds = array('id_jabatan'=>$jabfung['id_jabatan']);  
     $data['struktur'] = $this->m_umum->ambil_order_kondisi_2tabel_result('nkr_kewenangan',$knds,'nkr_kompetensi','id_kompetensi','nama_kewenangan','ASC');
     $this->load->view("admin_asesor/isi",$data);
    }
    if($mode=='simpan_tambah_kewenangan'){
     $status_pengajuan = $this->input->post('status_pengajuan');
     $barcode_pengajuan = $this->input->post('barcode_pengajuan');
     if($status_pengajuan == 3){
       $this->m_admin_asesor->edit_pegajuan_signature();
      $this->session->set_flashdata('sukses', 'Data Berhasil Di Simpan');
      redirect(base_url('admin_asesor/pengajuan_rkk'));    
     }else{
      $this->session->set_flashdata('danger', 'RKK Sudah Pernah Di Print');
      redirect(base_url('admin_asesor/pengajuan_rkk'));
     }
    }
    if($mode=='edit_sign'){
     $data['page'] =  $data['page']."_edit_sign"; 
     $kondisi = array('id_signature'=>$data['id']);  
     $keuangan = $this->m_umum->ambil_data_kondisi_2tabel_row('ol_pengajuan_signature',$kondisi,'ol_pengajuan','barcode_pengajuan');
     $data['barcode_pengajuan']  = set_value('barcode_pengajuan',$keuangan["barcode_pengajuan"]);
     $data['status_pengajuan']  = set_value('status_pengajuan',$keuangan["status_pengajuan"]);
     $data['lampiran']  = set_value('lampiran',$keuangan["lampiran"]);
     $data['kop_signature']  = set_value('kop_signature',$keuangan["kop_signature"]);
     $data['no']  = set_value('no',$keuangan["no"]);
     $data['tanggal']  = set_value('tanggal',$keuangan["tanggal"]);
     $data['id_gambar']  = set_value('id_gambar',$keuangan["id_gambar"]);
     $data['header']  = set_value('header',$keuangan["header"]);
     $data['sub_header']  = set_value('sub_header',$keuangan["sub_header"]);
     $data['sub_sub_header']  = set_value('sub_sub_header',$keuangan["sub_sub_header"]);
     $data['sebelum']  = set_value('sebelum',$keuangan["sebelum"]);
     $data['sesudah']  = set_value('sesudah',$keuangan["sesudah"]);
     $data['kanan_tgl']  = set_value('kanan_tgl',$keuangan["kanan_tgl"]);
     $data['tengah_tgl']  = set_value('tengah_tgl',$keuangan["tengah_tgl"]);
     $data['kiri_tgl']  = set_value('kiri_tgl',$keuangan["kiri_tgl"]);
     $data['kanan_top']  = set_value('kanan_top',$keuangan["kanan_top"]);
     $data['kanan_middle']  = set_value('kanan_middle',$keuangan["kanan_middle"]);
     $data['kanan_nama']  = set_value('kanan_nama',$keuangan["kanan_nama"]);    
     $data['kanan_nip']  = set_value('kanan_nip',$keuangan["kanan_nip"]);    
     $data['tengah_top']  = set_value('tengah_top',$keuangan["tengah_top"]);    
     $data['tengah_middle']  = set_value('tengah_middle',$keuangan["tengah_middle"]);    
     $data['tengah_nama']  = set_value('tengah_nama',$keuangan["tengah_nama"]);    
     $data['tengah_nip']  = set_value('tengah_nip',$keuangan["tengah_nip"]);    
     $data['kiri_top']  = set_value('kiri_top',$keuangan["kiri_top"]);    
     $data['kiri_middle']  = set_value('kiri_middle',$keuangan["kiri_middle"]);    
     $data['kiri_nama']  = set_value('kiri_nama',$keuangan["kiri_nama"]);    
     $data['kiri_nip']  = set_value('kiri_nip',$keuangan["kiri_nip"]); 
     $data['kiri_signature']  = set_value('kiri_signature',$keuangan["kiri_signature"]); 
     $data['tengah_signature']  = set_value('tengah_signature',$keuangan["tengah_signature"]); 
     $data['kanan_signature']  = set_value('kanan_signature',$keuangan["kanan_signature"]); 
     $this->load->view("admin_asesor/isi",$data);
    }
    if($mode=='simpan_edit_sign'){
      $status_pengajuan = $this->input->post('status_pengajuan');
      if($status_pengajuan == 3){
       if($this->m_admin_asesor->edit_signature()){
        $this->session->set_flashdata('sukses', 'Data Berhasil Di Simpan');
        redirect(base_url('admin_asesor/pengajuan_rkk'));
       }else{
        $this->session->set_flashdata('danger', 'Ada Kesalahan Edit Data');
        redirect(base_url('admin_asesor/pengajuan_rkk'));
       }
      }else{
        $this->session->set_flashdata('danger', 'Data Sudah Pernah Print Out');
        redirect(base_url('admin_asesor/pengajuan_rkk'));
      }
    }
    if($mode=='pdf_rkk'){
      $report = $this->load->view('cetak/ol_pengajuan_rkk', $data, TRUE);
      $signature = $this->m_ol_rancak->ambil_data_pengajuan_signature($data['id']);
      $filename = date('dmYHis').'-rkk-'.$signature['barcode_pengajuan'].'-'.$signature['nama_pegawai'].".pdf";
      $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => 'Legal-P']);
      $mpdf->AddPage('P', '', '', '', 2, 5, 5, 5, 10, 3, 3);
      $mpdf->SetTitle($data['header']);
      $mpdf->SetAuthor($data['instance_name']);
      $mpdf->SetHTMLFooter('<div style="text-align: center">Halaman {PAGENO} dari {nbpg}</div>');
      //$mpdf->SetFooter('Page : {PAGENO}');
      ini_set("pcre.backtrack_limit", "5000000");
      $mpdf->WriteHTML($report);
      $mpdf->Output($filename,\Mpdf\Output\Destination::INLINE);
    }
   }
  }
//===================================================================
//========================= TOOLS ===================================
//===================================================================
function tampil($data)
{
	$this->load->view("admin_asesor/header",$data);
	$this->load->view("admin_asesor/isi");
	$this->load->view("footer");
	$this->load->view("admin_asesor/jsload");
	$this->load->view("admin_asesor/jscode");
}
function tampil_top($data)
{
	$this->load->view("header_topol",$data);
	$this->load->view("admin_asesor/isi");
	$this->load->view("footer");
	$this->load->view("admin_asesor/jsload");
	$this->load->view("admin_asesor/jscode");
}
// -----------------------------------------------------------END-----------------------------------------
}
