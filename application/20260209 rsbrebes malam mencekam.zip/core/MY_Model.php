<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MY_Model extends CI_Model
{
    protected $table;
    protected $pk = 'id';

    public function __construct()
    {
        parent::__construct();
    }

    /* =========================
     * INSERT
     * ========================= */
    public function insert(array $data)
    {
        $data['created_at'] = date('Y-m-d H:i:s');

        $ok = $this->db->insert($this->table, $data);

        return $ok
            ? $this->success('Data berhasil disimpan')
            : $this->fail('Gagal menyimpan data');
    }
/*
controller
public function save()
{
    $data = $this->input->post();
    $result = $this->My_model->insert($data);
    echo json_encode($result);
}
Contoh di JavaScript (SweetAlert2)
$.ajax({
    url: '/save',
    method: 'POST',
    data: $('#form').serialize(),
    dataType: 'json',
    success: function (res) {
        Swal.fire({
            icon: res.status === 'sukses' ? 'success' : 'error',
            title: res.status === 'sukses' ? 'Berhasil' : 'Gagal',
            text: res.message
        });

        if (res.status === 'sukses') {
            // misal reload table
            location.reload();
        }
    }
});
Sedikit Saran Biar Lebih “SweetAlert-ready”
Kalau mau lebih rapi, kamu bisa samakan nama status dengan icon SweetAlert2:
protected function success($msg)
{
    return [
        'status'  => 'success',
        'message' => $msg
    ];
}

protected function fail($msg)
{
    return [
        'status'  => 'error',
        'message' => $msg
    ];
}
Lalu JS jadi super simpel:
Swal.fire({
    icon: res.status,
    text: res.message
});

public function save()
{
    $result = $this->My_model->insert($this->input->post());
    $this->json($result);
}
$('#form').on('submit', function (e) {
    e.preventDefault();

    $.ajax({
        url: '<?= site_url("user/save") ?>',
        type: 'POST',
        data: $(this).serialize(),
        dataType: 'json',
        success: function (res) {

            Swal.fire({
                icon: res.status,      // success | error
                title: res.status === 'success' ? 'Berhasil' : 'Gagal',
                text: res.message
            });

            if (res.status === 'success') {
                // contoh aksi setelah sukses
                $('#form')[0].reset();
            }
        },
        error: function () {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Server tidak merespon'
            });
        }
    });
});
*/
    /* =========================
     * UPDATE
     * ========================= */
    public function update(array $where, array $data)
    {
        if (!$where) {
            return $this->fail('Kondisi update kosong');
        }

        $data['updated_at'] = date('Y-m-d H:i:s');

        $ok = $this->db
            ->where($where)
            ->update($this->table, $data);

        return $ok
            ? $this->success('Data berhasil diperbarui')
            : $this->fail('Gagal memperbarui data');
    }

    /* =========================
     * AUTO INSERT / UPDATE
     * ========================= */
    public function upsert(array $where, array $data)
    {
        if (!$this->exists($where)) {
            return $this->insert(array_merge($where, $data));
        }

        return $this->update($where, $data);
    }

    /* =========================
     * SOFT DELETE
     * ========================= */
    public function soft_delete(array $where, $userId = null)
    {
        return $this->update($where, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'deleted_by' => $userId
        ]);
    }

    /* =========================
     * RESTORE
     * ========================= */
    public function restore(array $where)
    {
        return $this->update($where, [
            'deleted_at' => null,
            'deleted_by' => null
        ]);
    }

    /* =========================
     * HARD DELETE
     * ========================= */
    public function force_delete(array $where)
    {
        if (!$where) {
            return $this->fail('Kondisi delete kosong');
        }

        $ok = $this->db->where($where)->delete($this->table);

        return $ok
            ? $this->success('Data dihapus permanen')
            : $this->fail('Gagal menghapus permanen');
    }

    /* =========================
     * HELPER
     * ========================= */
    public function exists(array $where)
    {
        return $this->db
            ->where($where)
            ->count_all_results($this->table) > 0;
    }

    public function find(array $where)
    {
        return $this->db
            ->where($where)
            ->where('deleted_at IS NULL', null, false)
            ->get($this->table)
            ->row_array();
    }

    /* =========================
     * RESPONSE STANDARD
     * ========================= */
    protected function success($msg)
    {
        return [
            'status'  => 'sukses',
            'message' => $msg
        ];
    }

    protected function fail($msg)
    {
        return [
            'status'  => 'danger',
            'message' => $msg
        ];
    }
    protected function datatable_search($columns, $search, $dtCols)
    {
        // Global search
        if (!empty($search['value'])) {
            $this->db->group_start();
            foreach ($columns as $col) {
                if ($col) {
                    $this->db->or_like($col, $search['value']);
                }
            }
            $this->db->group_end();
        }

        // Column search
        foreach ($dtCols as $i => $col) {
            if (
                isset($col['search']['value']) &&
                $col['search']['value'] !== '' &&
                isset($columns[$i]) &&
                $columns[$i]
            ) {
                $this->db->like($columns[$i], $col['search']['value']);
            }
        }
    }
}