<!--  <footer class="main-footer no-print"> -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <?php echo $ilicensed; ?>
    </div>
    <?php echo $ifooter; ?>
  </footer>
  <div class="control-sidebar-bg"></div>
</div>