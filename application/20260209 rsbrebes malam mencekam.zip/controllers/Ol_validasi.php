<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Makassar');

class Ol_validasi extends MY_Controller
{
// -----------------------------------------------------------START-----------------------------------------
  public function __construct(){
    parent::__construct();
    $this->load->model('m_ol_rancak');
    $this->load->model('m_ol_validasi');
    $this->load->model('m_auth');
    $this->m_auth->validator();
  }
  // ========================================================================
    function menu_halaman()
    {
        return 
            [
                [
                    'type'  => 'title',
                    'label' => 'Member'
                ],
                [
                    'type'   => 'parent',
                    'id'     => 'member-tools',
                    'label'  => 'Halaman',
                    'icon'   => 'ph-duotone ph-user',
                    'children' => [
                        ['label'=>'Profil','url'=>'member/profil'],
                        ['label'=>'Log Out','url'=>'logout']
                    ]
                ]
            ];
    }
  // ========================================================================
	function index(){
		$data['page']="home";
		$data['header'] = "BERANDA";
		$data['title'] = "BERANDA";
		$pegawai=$this->m_ol_rancak->ambil_user_pegawai($this->session->id_user);
		$instansi = $this->m_umum->ambil_data('a_instansi','id_instansi',1);
		$data['instance_id'] = $instansi["id_instansi"];
		$data['instance_name'] = $instansi["nama_instansi"];
		$data['idescription'] = $instansi["description"];
		$data['ikeywords'] = $instansi["keywords"];
		$data['iheader'] = $instansi["header"];
		$data['iheader_mini'] = $instansi["header_mini"];
		$data['ifooter'] = $instansi["footer"];
		$data['ilicensed'] = $instansi["licensed"];
		$data['member_id'] = $pegawai["id_pegawai"];
		$data['member_name'] = $pegawai["nama_pegawai"];
		$data['level_name'] = $pegawai["nama_level"];
		$data['photo'] = $pegawai["foto"];		
		//======================= IMPORTANT =========================================
	//	$this->tampil_top($data);
		$this->validasi();
	}
	function validasi($mode='view'){
      $instansi = $this->m_umum->ambil_data('a_instansi', 'id_instansi', 1);
      $pegawai = $this->m_ol_rancak->ambil_user_pegawai($this->session->id_user);
      $data = [
          'page'          => 'validasi',
          'header'        => 'VALIDASI KEGIATAN LOGBOOK PEGAWAI / USER',
          'title'         => 'DATA KEWENANGAN YANG BELUM TERVALIDASI',
          'instance_id'   => $instansi['id_instansi'],
          'instance_name' => $instansi['nama_instansi'],
          'idescription'  => $instansi['description'],
          'ikeywords'     => $instansi['keywords'],
          'iheader'       => $instansi['header'],
          'iheader_mini'  => $instansi['header_mini'],
          'ifooter'       => $instansi['footer'],
          'ilicensed'     => $instansi['licensed'],
          'member_id'     => $pegawai['id_pegawai'],
          'member_name'   => $pegawai['nama_pegawai'],
          'level_name'    => $pegawai['nama_level'],
          'photo'         => $pegawai['foto'],
          'link_awal'     => base_url('ol_validasi'),
          'jeson'          => $this->m_ol_validasi->ambil_data_pegawai_dttb(),
          'menu'          => $this->merge_menu($this->menu_halaman())

      ];		
		//======================= IMPORTANT =========================================
		$data['id']   = $this->uri->segment(4);
		$data['id2']   = $this->uri->segment(5);
		$data['id3']   = $this->uri->segment(6);
        $data['id4']   = $this->uri->segment(7);
		if($mode=='view'){
			$this->tampil_ra($data);
		}
		if($mode=='data'){
	        $dt = $this->datatable_request();
	        $res = $this->m_ol_validasi->datatable_pegawai($dt);

	        $this->datatable_response(
	            $dt['draw'],
	            $res['total'],
	            $res['filtered'],
	            $res['data']
	        );
		}
		if($mode=='child_pegawai'){
		//	$pegawai = (int) $this->input->post('barcode_pegawai');
        //    $pegawai = trim($this->input->post('barcode_pegawai'));
            $pegawai = $this->input_auto('barcode_pegawai');
			$dt      = $this->datatable_request();
			$res = $this->m_ol_validasi->datatable_child($pegawai, $dt);
			$this->datatable_response(
			    $dt['draw'],
			    $res['total'],
			    $res['filtered'],
			    $res['data']
			);
		}
  if($mode=='logbook'){
      $pegawai = $this->input_auto('barcode_pegawai');
      if (!$pegawai) {
       show_error('Barcode pegawai tidak valid', 400);
      }
      $dt = $this->datatable_request();
      $res = $this->m_ol_validasi->datatable_logbook($pegawai, $dt);

    //  log_message('error', json_encode($_POST, JSON_PRETTY_PRINT));

      $this->datatable_response(
       $dt['draw'],
       $res['total'],
       $res['filtered'],
       $res['data']
      );
  }
	else{
/*	   $data['rkk'] = $this->m_rancak->cmd_status_rkk();
	   $data['sifat_kewenangan'] = $this->m_ol_rancak->cmd_sifat_kewenangan();*/
	if($mode=='validasi'){
        if (empty($data['id'])) {
            redirect('ol_validasi');
        }

        if ($this->m_ol_validasi->cek_pegawai($data['id']) == 0) {
            redirect('member');
        }

        $data['page'] .= '_validasi';
        $this->tampil_ra($data);
  	}
    if($mode=='rkk'){
      $data['page'] =  $data['page']."_rkk";
        $logbook = $this->m_umum->ambil_data_kondisi(
            'ol_logbook',
            [
                'id_logbooker'  => $data['id2'],
                'id_kewenangan' => $data['id']
            ],
            'id_kewenangan'
        );

        $pegawai = $this->m_umum->ambil_data(
            'ol_pegawai',
            'id_pegawai',
            $logbook['id_logbooker']
        );

        $data += [
            'attr_ra'              => [ 'class' => 'select-example' ],
            'barcode_pegawai'      => $pegawai['barcode_pegawai'],
            'rkk'                  => $this->m_rancak->cmd_status_rkk(),
            'statuse'              => $this->m_rancak->cmd_status(),
            'sifat_kewenangan'     => $this->m_ol_rancak->cmd_sifat_kewenangan(),
            'id_sifat_kewenangan'  => set_value('id_sifat_kewenangan', $data['id3']),
            'status_validasi'      => set_value('status_validasi',$this->input->post("status_validasi"))
        ];
/*      $kondisi = array('id_logbooker'=>$data['id2'],'id_kewenangan'=>$data['id']);
      $apk = $this->m_umum->ambil_data_kondisi('ol_logbook',$kondisi,'id_kewenangan');
      $peg = $this->m_umum->ambil_data('ol_pegawai','id_pegawai',$apk["id_logbooker"]);
      $data['barcode_pegawai']  = $peg["barcode_pegawai"];
      $data['rkk'] = $this->m_rancak->cmd_status_rkk();
      $data['statuse'] = $this->m_rancak->cmd_status();
      $data['id_sifat_kewenangan']  = set_value('id_sifat_kewenangan',$data['id3']);
      $data['status_validasi']  = set_value('status_validasi',$this->input->post("status_validasi"));*/
      $this->load->view("ol_validasi/isi",$data);
    }
    if($mode=='simpan_rkk'){
        if (!$this->input->is_ajax_request()) {
            swal_response([
                'status'  => 'error',
                'title'   => 'Akses Ditolak',
                'message' => 'Request tidak valid'
            ]);
        }

        $result = $this->m_ol_validasi->simpan_rkk(
            $this->input->post('id_kewenangan'),
            $this->input->post('barcode_pegawai'),
            $this->input->post('id_sifat_kewenangan'),
            $this->input->post('status_validasi')
        );

        swal_response(array_merge($result, [
            'reload' => true
        ]));
/*     $id_sifat_kewenangan=$this->input->post('id_sifat_kewenangan');
     $id_kewenangan=$this->input->post('id_kewenangan');
     $barcode_pegawai=$this->input->post('barcode_pegawai');
     $kondisi2=array('barcode_pegawai'=>$barcode_pegawai,'id_kewenangan'=>$id_kewenangan);
     $kondisi=array('barcode_pegawai'=>$barcode_pegawai,'id_kewenangan'=>$id_kewenangan,'id_sifat_kewenangan'=>$id_sifat_kewenangan);
     $jml2 = $this->m_umum->jumlah_record_filter('ol_validasi',$kondisi2);
     $jml = $this->m_umum->jumlah_record_filter('ol_validasi',$kondisi);
     if($id_kewenangan && $barcode_pegawai){
      if($jml2 == 0){
       if($this->m_ol_validasi->simpan_ol_validasi($id_kewenangan,$barcode_pegawai,$id_sifat_kewenangan)){
        $this->session->set_flashdata('sukses', 'Data Sudah Di Rubah');
        redirect(base_url('ol_validasi/validasi/validasi/'.$barcode_pegawai));
       }else{
        $this->session->set_flashdata('danger', 'Ada Masalah Rubah Data. Hubungi Admin');
        redirect(base_url('ol_validasi/validasi/validasi/'.$barcode_pegawai));
       }
      }else{
       if($jml == 0){
        if($this->m_ol_validasi->rubah_ol_validasi($id_kewenangan,$barcode_pegawai,$id_sifat_kewenangan)){
         $this->session->set_flashdata('sukses', 'Data Sudah Di Rubah');
         redirect(base_url('ol_validasi/validasi/validasi/'.$barcode_pegawai));
        }else{
         $this->session->set_flashdata('danger', 'Ada Masalah Rubah Data. Hubungi Admin');
         redirect(base_url('ol_validasi/validasi/validasi/'.$barcode_pegawai));
        }
       }else{
        $this->session->set_flashdata('danger', 'Data Sudah Masuk RKK');
        redirect(base_url('ol_validasi/validasi/validasi/'.$barcode_pegawai));
       }
      }
     }else{
      redirect(base_url('ol_validasi/validasi/validasi/'.$barcode_pegawai));
     }*/
    }
		}
	}
public function update_cell()
{
    $id    = $this->input->post('id');
    $field = $this->input->post('field');
    $value = $this->input->post('value');

    // whitelist field (WAJIB)
    $allowed = ['nama_pegawai','nip'];

    if (!in_array($field, $allowed)) {
        show_error('Invalid field', 403);
    }

    $this->db->where('id_pegawai', $id);
    $this->db->update('ol_pegawai', [
        $field => $value
    ]);

    echo json_encode(['status' => true]);
}
public function update_cells()
{
    $id    = $this->input->post('id');
    $field = $this->input->post('field');
    $value = $this->input->post('value');

    // WHITELIST
    $allowed = ['status_asesor'];
    if (!in_array($field, $allowed)) {
        echo json_encode(['status'=>false,'message'=>'Field tidak diizinkan']);
        return;
    }

    $this->db->where('id_pegawai', $id)
             ->update('ol_user', [$field => $value]);

    // ambil text baru
    $text = $this->db->select('nama_komite')
                     ->from('kol_komite')
                     ->where('id_komite', $value)
                     ->get()->row()->nama_komite;

    echo json_encode([
        'status' => true,
        'text'   => $text
    ]);
}
//===================================================================
//========================= TOOLS ===================================
//===================================================================
function tampil($data)
{
	$this->load->view("ol_validasi/header",$data);
	$this->load->view("ol_validasi/isi");
	$this->load->view("footer");
	$this->load->view("ol_validasi/jsload");
	$this->load->view("ol_validasi/jscode");
}
function tampil_ra($data)
{
	$this->load->view("header_top_ra",$data);
	$this->load->view("ol_validasi/isi");
	$this->load->view("footer_ra");
	$this->load->view("jsload_ra");
	$this->load->view("ol_validasi/jscode");
}
function tampil_top($data)
{
	$this->load->view("header_topol",$data);
	$this->load->view("ol_validasi/isi");
	$this->load->view("footer");
	$this->load->view("ol_validasi/jsload");
	$this->load->view("ol_validasi/jscode");
}
// -----------------------------------------------------------END-----------------------------------------
}
