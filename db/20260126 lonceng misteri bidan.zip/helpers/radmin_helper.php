<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//======================================= ui
function input_pdselect2($name, $options, $selected = '', $attr = FALSE)
{
    // default attribute
    if ($attr === FALSE) {
        $attr = [];
    }

    // default id = name
    if (!isset($attr['id'])) {
        $attr['id'] = $name;
    }

    // default class select2
    if (!isset($attr['class'])) {
        $attr['class'] = 'form-control select2';
    }
/*    else {
        $attr['class'] .= ' select2';
    }*/

    echo form_dropdown($name, $options, $selected, $attr);
}

/*
// AUTO PLACEHOLDER
$attr = [
    'data-placeholder' => 'Pilih Bulan'
];
input_pdselect2('bulan', $cmd_bulan, '', $attr);

// multi select
$attr = [
    'id' => 'user_multi',
    'multiple' => 'multiple'
];
input_pdselect2('user_id[]', $users, [1,3], $attr);

// ajax select2
$attr = [
    'id' => 'customer',
    'class' => 'form-control select2-ajax',
    'data-url' => site_url('ajax/customer'),
    'data-placeholder' => 'Cari customer'
];
input_pdselect2('customer_id', [], '', $attr);

// DEPENDENT DROPDOWN (PARENT)
$attr = [
    'id' => 'provinsi_id',
    'data-child' => 'kota_id',
    'data-url' => site_url('ajax/get_kota'),
    'onchange' => 'loadKota(this)'
];
input_pdselect2('provinsi', $provinsi, '', $attr);

// DEPENDENT DROPDOWN (CHILD) / ID
$attr = [
    'id' => 'kota_id'
];
input_pdselect2('kota', [], '', $attr);

// FILTER LAPORAN (AUTO SUBMIT)
$attr = [
    'id' => 'tahun',
    'onchange' => 'filterLaporan()'
];
input_pdselect2('tahun', $cmd_tahun, date('Y'), $attr);

// DISABLED / READONLY / REQUIRED
$attr = [
    'id' => 'status',
    'disabled' => 'disabled',
    'required' => 'required'
];
input_pdselect2('status', $status, '1', $attr);

// CUSTOM CLASS
$attr = [
    'class' => 'form-control select2 select-sm'
];
input_pdselect2('bank', $bank, '', $attr);

----------------------- JS GLOBAL (SATU KALI SAJA) ----------------
<script>
$('.select2').select2({
    width: '100%',
    placeholder: function(){
        return $(this).data('placeholder') || 'Pilih data';
    },
    allowClear: true
});

$('.select2-ajax').each(function(){
    let el = $(this);
    el.select2({
        ajax: {
            url: el.data('url'),
            dataType: 'json',
            delay: 250,
            data: params => ({ q: params.term }),
            processResults: data => ({ results: data })
        },
        placeholder: el.data('placeholder'),
        allowClear: true
    });
});
</script>

1️⃣ AUTO-INIT JS PAKAI DATA-ATTRIBUTE (ZERO CONFIG JS)

🎯 Tujuan
- Tidak perlu JS per dropdown
- Semua behavior dikontrol lewat HTML attribute
- 1 JS global untuk semua halaman

✅ DATA-ATTRIBUTE STANDARD
-------------------------------------------
| Attribute            | Fungsi           |
| -------------------- | ---------------- |
| `data-select2`       | aktifkan select2 |
| `data-placeholder`   | placeholder      |
| `data-ajax-url`      | AJAX endpoint    |
| `data-parent`        | parent ID        |
| `data-child`         | child ID         |
| `data-tags`          | tagging          |
| `data-minimum-input` | min search       |
| `multiple`           | multi select     |
-------------------------------------------

🔹 JS GLOBAL (SATU FILE)
<script>
$(document).ready(function(){

    $('[data-select2]').each(function(){
        let el = $(this);

        let config = {
            width: '100%',
            placeholder: el.data('placeholder') || 'Pilih data',
            allowClear: true
        };

        // AJAX Select2
        if (el.data('ajax-url')) {
            config.ajax = {
                url: el.data('ajax-url'),
                dataType: 'json',
                delay: 250,
                data: params => ({ q: params.term }),
                processResults: data => ({ results: data }),
                cache: true
            };
            config.minimumInputLength = el.data('minimum-input') || 1;
        }

        // TAGGING
        if (el.data('tags')) {
            config.tags = true;
            config.tokenSeparators = [','];
        }

        el.select2(config);
    });

    // DEPENDENT DROPDOWN
    $('[data-parent]').on('change', function(){
        let parent = $(this);
        let child  = $('#' + parent.data('child'));

        $.post(parent.data('ajax-url'), { id: parent.val() }, function(res){
            child.html(res).trigger('change');
        });
    });

});
</script>

🔹 HELPER KHUSUS SELECT2 TAGGING
   Tanpa helper baru, cukup attr

$attr = [
    'data-select2' => '1',
    'data-tags' => '1',
    'data-placeholder' => 'Tambah tag'
];
input_pdselect2('tags[]', [], [], $attr);

✔ bisa input manual
✔ bisa multi value
✔ cocok untuk kategori, keyword, label
*/
//======================================= helper
function swal_response($params = [])
{
    $CI =& get_instance();

    $payload = array_merge([
        'status'   => 'info',
        'title'    => '',
        'message'  => '',
        'ra_btn'   => [],
        'reload'   => false,
        'redirect' => null,
        'data'     => null,
    ], $params);

    if ($CI->input->is_ajax_request()) {
        $CI->output
           ->set_content_type('application/json')
           ->set_output(json_encode($payload))
           ->_display();
        exit;
    }

    // fallback NON-AJAX
    $CI->session->set_flashdata('swal', $payload);
    if ($payload['redirect']) redirect($payload['redirect']);
}

function swal_confirm($title, $message, $buttons = [])
{
    swal_response([
        'status'  => 'confirm',
        'title'   => $title,
        'message' => $message,
        'ra_btn'  => $buttons
    ]);
}
/**
 * controller_page
 * Mengembalikan array metadata standar untuk controller
 * @param array $custom Optional override default metadata
 * @return array
 */
if (!function_exists('controller_page')) {
    function controller_page($custom = []) {
        return array_merge([
            'page'         => 'default_page',
            'header'       => 'Header Default',
            'title'        => 'Title Default',
            'link_kembali' => base_url(),
            'link_awal'    => base_url(),
            'link_daftar'  => base_url(),
            'link_tambahan'=> base_url(),
        ], $custom);
    }
}
/**
 * controller_data_override
 * Override $data default dengan $custom
 * @param array $data Default data
 * @param array $custom Data tambahan / override
 * @return array
 */
if (!function_exists('controller_data_override')) {
    function controller_data_override(array &$data, array $custom = []) {
        $data = array_merge($data, $custom);
        return $data;
    }
}