<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MY_Controller extends CI_Controller
{
    protected $user_tz;
    protected $menu_master = [];
    public function __construct()
    {
        parent::__construct();
        // timezone dari session (JS browser)
        $this->user_tz = $this->session->userdata('timezone') ?: 'Asia/Jakarta';
        // SERVER & DB tetap UTC
        date_default_timezone_set('UTC');

        $menu_default = $this->menu_master_default();
        $menu_online_all = $this->menu_online();              // SEMUA a_online
        $menu_online_enabled = $this->menu_online_enabled();

        // 👉 TOTAL 4 MENU
        $this->menu_master = array_merge(
            $menu_default,
            $menu_online_all,
            $menu_online_enabled
        );
    }
    protected function menu_master_default()
    {
        return [
            [
                'type'  => 'title',
                'label' => 'Component'
            ],
            [
                'type'   => 'parent',
                'id'     => 'master',
                'label'  => 'Utama',
                'icon'   => 'ph-duotone ph-database',
                'children' => [
                    ['label'=>'Biodata',            'url'=>'member/profil'],
                    ['label'=>'Logbook',            'url'=>'ol_logbook'],
                    ['label'=>'Latihan Pengajuan',  'url'=>'member/tes'],
                    ['label'=>'Berkas',             'url'=>'member/berkas'],
                    ['label'=>'Ijasah',             'url'=>'member/ijasah'],
                    ['label'=>'Pelatihan',          'url'=>'member/pelatihan'],
                    ['label'=>'Surat Ijin',         'url'=>'member/surat_ijin']
                ]
            ]
        ];
    }
    /* ===============================
       MENU ONLINE (DB)
    ================================ */
    protected function menu_online()
    {
        $rows = $this->m_ol_rancak->ambil_data_a_online();

        if (!$rows) return [];

        $children = [];
        foreach ($rows as $r) {
            $children[] = [
                'label' => $r['nama_menu'],
                'url'   => $r['kode_online']
            ];
        }

        return [
            [
                'type'   => 'parent',
                'id'     => 'menu-level',
                'label'  => 'Menu Online',
                'icon'   => 'ph-duotone ph-globe',
                'children' => $children
            ]
        ];
    }
    protected function menu_online_enabled()
    {
        if (empty($this->session->id_pegawai)) {
            return [];
        }

        $rows = $this->m_ol_rancak->ambil_data_a_enabled();

        if (!$rows) return [];

        $children = [];
        foreach ($rows as $r) {
            $children[] = [
                'label' => $r['nama_menu'],
                'url'   => $r['kode_online']
            ];
        }

        return [
            [
                'type'   => 'parent',
                'id'     => 'online-service',
                'label'  => 'Menu Level',
                'icon'   => 'ph-duotone ph-globe',
                'children' => $children
            ]
        ];
    }
    protected function merge_menu(array $extra = [])
    {
        return array_merge($extra, $this->menu_master);
    }
    protected function datatable_request()
    {
        return [
            'draw'   => (int) $this->input->post('draw'),
            'start'  => (int) $this->input->post('start'),
            'length' => (int) $this->input->post('length'),
            'search' => $this->input->post('search'),
            'order'  => $this->input->post('order'),
            'cols'   => $this->input->post('columns') ?? []
        ];
    }
    protected function datatable_response($draw, $total, $filtered, $data)
    {
        echo json_encode([
            'draw'            => $draw,
            'recordsTotal'    => $total,
            'recordsFiltered' => $filtered,
            'data'            => $data
        ]);
    }
    /**
     * AUTO INPUT DETECTOR
     * - POST > GET > NULL
     * - ENUM → INT → STRING
     */
    function input_auto($key, $enum = null, $required = true)
    {
        $CI =& get_instance();

        // PRIORITAS POST → GET
        $val = $CI->input->post($key, true);
        if ($val === null) {
            $val = $CI->input->get($key, true);
        }

        if ($val === null || $val === '') {
            if ($required) {
                show_error("Input {$key} wajib diisi", 400);
            }
            return null;
        }

        $val = trim((string) $val);

        // =====================
        // 1️⃣ ENUM
        // =====================
        if (is_array($enum)) {
            if (!in_array($val, $enum, true)) {
                show_error("Input {$key} tidak valid (ENUM)", 403);
            }
            return $val;
        }

        // =====================
        // 2️⃣ INTEGER
        // =====================
        if (ctype_digit($val)) {
            return (int) $val;
        }

        // =====================
        // 3️⃣ STRING
        // =====================
        return $val;
    }
    /**
     * SAFE URI SEGMENT
     * Auto INT / STR / ENUM
     */
    function uri_auto($segment, $enum = null, $required = true)
    {
        $CI =& get_instance();

        $val = $CI->uri->segment($segment);

        if ($val === null || $val === '') {
            if ($required) {
                show_error("URI segment {$segment} wajib diisi", 404);
            }
            return null;
        }

        $val = trim((string) $val);

        // ENUM
        if (is_array($enum)) {
            if (!in_array($val, $enum, true)) {
                show_error("URI segment {$segment} tidak valid", 403);
            }
            return $val;
        }

        // INT
        if (ctype_digit($val)) {
            return (int) $val;
        }

        // STRING
        return $val;
    }
    function uri_int($segment, $required = true)
    {
        $CI =& get_instance();
        $val = $CI->uri->segment($segment);

        if ($val === null || $val === '') {
            if ($required) show_error("URI segment {$segment} wajib diisi", 404);
            return null;
        }

        if (!ctype_digit($val)) {
            show_error("URI segment {$segment} harus angka", 400);
        }

        return (int) $val;
    }
    /*
$barcode = $this->uri_auto(4, null, false);

if ($barcode !== null && !is_int($barcode)) {
    show_error('Barcode harus angka', 400);
} 
atau
$barcode = $this->uri_int(4, false);
uri_auto($segment, $enum = null, $required = true);
$barcode = $this->uri_auto(4); artinya
$segment = 4
$enum    = null
$required= true
| URI             | Hasil       |
| --------------- | ----------  |
| `/validasi/123` | `int(123)`  |
| `/validasi/abc` | `"abc"`     |
| `/validasi/`    | ❌ **404**  |

$barcode = $this->uri_auto(4, null, false);
$segment = 4
$enum    = null
$required= false
| URI             | Hasil      |
| --------------- | ---------- |
| `/validasi/123` | `int(123)` |
| `/validasi/abc` | `"abc"`    |
| `/validasi/`    | `null` ✅   |

    */
}