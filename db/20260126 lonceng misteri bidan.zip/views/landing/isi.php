<?php
if ($page=="home")
{
?>
			<!-- INTRO -->
			<div class="section bg-light position-relative overflow-hidden overlay-dark overlay-opacity-8 bg-cover jarallax" style="background-image:url('assets/images/ilya-pavlov-OqtafYT5kTw-unsplash.jpg')">
				
				<div class="container position-relative z-index-2 py-7 d-middle"> 
						
					<div class="text-center text-white py-7 p-0-xs" data-aos="fade-in" data-aos-delay="0" data-aos-offset="0">

						<!-- main title -->
						<h1 class="display-5 fw-bold mb-0 fw-light">
							<b class="text-success">Indikator Mutu dan Kredensial Komite</b> <span class="typed" 
												data-typed-string="Medik|Keperawatan|Nakes Lainnya"
												data-typed-speed-forward="80" 
												data-typed-speed-back="40" 
												data-typed-back-delay="700" 
												data-typed-loop-times="infinite" 
												data-typed-smart-backspace="true" 
												data-typed-shuffle="false" 
												data-typed-cursor="|"></span>
						</h1>
						
						<!-- slogan -->
						<p class="h5 fw-normal mb-0">
							Program Kredensial dan Indikator Mutu Kompatible untuk Semua Profesi
						</p>

				<!--	-->	<div class="clearfix py-7">
							<a href="<?php echo base_url('masuk');?>" class="btn btn-lg btn-success transition-hover-top border-0 d-block-xs">
								LOGIN
							</a>
							
							<span class="px-3 d-block-xs py-3"> Atau </span>
							
							<a href="<?php echo base_url('data/registrasi');?>" class="btn btn-lg btn-primary transition-hover-top border-0 d-block-xs">
								REGISTRASI
							</a>
						</div> 

					</div>

				</div>

				<div class="absolute-full w-100 overflow-hidden opacity-5 z-index-1">
					<img class="img-fluid" width="2000" height="2000" src="<?php echo base_url();?>assets/images/masks/shape-line-lense.svg" alt="...">
				</div>

				<!-- v shape : .bg-light, .shape-xs (remove .shape-xs for .vh-100 container) -->
				<div class="shape-v shape-xs bottom-0"></div>

			</div>	
			<!-- /INTRO -->					
<hr>
      <!-- block : parallax + progress -->
      <div class="section py-0 overflow-hidden">
        <div class="row g-0">

          <div class="order-1 order-lg-2 col-12 col-lg-5 min-h-300 overlay-dark overlay-opacity-5 bg-cover jarallax" style="background-image:url('assets/images/nakes.png')" data-speed="1.1">

            <!-- lines, looks like through a glass -->
            <div class="absolute-full w-100 overflow-hidden">
              <img class="img-fluid" width="2000" height="2000" src="<?php echo base_url();?>assets/images/masks/shape-line-lense.svg" alt="...">
            </div>


            <!-- svg wave -->
            <svg height="106%" style="transform: scaleX(-1);margin-top:-20px;margin-left:-15px;margin-right:-15px;" class="rtl-scalex-n1 position-absolute top-0 bottom-0 start-0 z-index-1 d-none d-lg-block" viewBox="0 0 93 471">
              <path fill="#FFFFFF" d="M92.8333333,0 C76.9444444,16.3333333 67.1666667,37 63.5,62 C58,99.5 73,144.5 63.5,202 C54,259.5 24,293 5,345.5 C-4.22382609,370.986888 6.1692873e-12,426.5 31.5,471 C31.5,471 52,471 93,471 L92.8333333,0 Z"></path>
            </svg>

          </div>

          <div class="order-2 order-lg-1 col-12 col-lg-7 text-align-end text-center-xs">

            <div class="d-inline-block max-w-600 mx-5 my-7 m-4-xs jarallax" data-jarallax-element="30">
              <h2 class="display-5 fw-bold my-5">
                <span class="text-primary">Program</span>  Kredensial
              </h2>


<p class="lead mb-5 fw-light"><strong><em>Telah hadir program kredensial untuk semua jabatan fungsional, pengajuan kompetensi bisa di lakukan disini tanpa membawa berkas cukup dengan data-data yang sudah di upload. Hasil / output bisa digunakan di akreditasi, eukom dll.<br />
<br />
OPPE atau On going Professional Practise Evaluation adalah suatu metode yang digunakan oleh institusi pelayanan kesehatan untuk melakukan evaluasi kinerja klinis, evaluasi pengembangan profesi dan evaluasi prilaku etik staf kesehatan yang memberikan pelayanan kesehatan di institusi tersebut<br />
<br />
Indikator Mutu untuk pelaporan di RS, Klinik, Puskesmas serta Instansi Lainnya dan sangat berguna untuk akreditasi<br />
<br />
Aplikasi ini tidak hanya berguna untuk pribadi tetapi juga untuk ruangan, komunitas (ppni,pari,ibi,idi dll) karena terdapat fitur laporan jaga, oppe (kinerja klinis, pengembangan profesi dan etika profesi), statistik dll.</em></strong></p>
<span style="font-size:14px"><strong><em>FITUR : </em></strong></span><br>


<strong><span style="font-size:14px"><em>Pembuatan Jadwal Ruangan</em></span></strong><br>
<strong><span style="font-size:14px"><em>Laporan Jaga</em></span></strong><br>
<strong><span style="font-size:14px"><em>Pengisian Logbook</em></span></strong><br>
<strong><span style="font-size:14px"><em>Bank Data Pegawai / Statistik</em></span></strong><br>
<strong><span style="font-size:14px"><em>Berkas Pegawai</em></span></strong><br>
<strong><span style="font-size:14px"><em>Analisa Jabatan dan Beban Kerja</em></span></strong><br>
<strong><span style="font-size:14px"><em>Laporan Quality Control Ruangan</em></span></strong><br>
<strong><span style="font-size:14px"><em>Output Laporan Hasil Kerja Pegawai untuk pengisian <a href="https://kinerja.bkn.go.id/login" target="_blank">EKinerja BKN</a></em></span></strong><br>
<strong><span style="font-size:14px"><em>Kredensial</em></span></strong><br>
             


							

            </div>

          </div>

        </div>

      </div>

			<!-- start :: blog content -->
			<div class="container py-6"> 

				<div class="col-lg-10 mx-auto">

<div class="callout alert alert-info mt-60 mb-60">

	<div class="row">

		<div class="col-md-8 col-sm-8"><!-- left text -->
			<h4>Kredensial <strong>ONLINE</strong></h4>
			<p>
				Aplikasi untuk kemudahan kredensial
			</p>
		</div><!-- /left text -->

		
		<div class="col-md-4 col-sm-4 text-right"><!-- right btn -->
			<a href="<?php echo base_url();?>" rel="nofollow" class="btn btn-info btn-lg">BERANDA</a>
		</div><!-- /right btn -->

	</div>

</div>
					<div class="article-format">

					</div>

				</div>

			</div>
			<!-- end :: blog content -->
			<!-- blog cover -->
		  <div class="bg-light">
		    <div class="container article-format">

		      <div class="row g-4 align-items-center">
		        
		        <div class="col position-relative mt-0">

		        	<!-- blog title -->
		          <header class="py-5">
		            <h1 class="mb-0 fw-bold">PROSES KREDENSIAL MENGGUNAKAN PROGRAM KAMI</h1>
		          </header>

		        </div>

		        <!-- blog image -->
		        <div class="col-lg-6 position-relative mt-0">
		          <svg class="d-none d-lg-block position-absolute h-100 top-0 text-light" style="margin-left:-3rem; width:6rem" fill="currentColor" viewBox="0 0 100 100" preserveAspectRatio="none">
		            <polygon points="50,0 100,0 50,100 0,100"></polygon>
		          </svg>
		          <picture class="mb-0">
		            <!-- <source media="(max-width: 576px)" srcset="{: $PostDetail.json_data.cover.0.storage.thumb.sm :}"> -->
		            <!-- <source media="(min-width: 1200px)" srcset="{: $PostDetail.json_data.cover.0.storage.thumb.sm :}"> -->
		            <img class="w-100 mb-0" src="<?php echo base_url();?>assets/images/desk.png" alt="...">
		          </picture>
		        </div>

		      </div>


		    </div>
		  </div>

			<!-- start :: blog content -->
			<div class="container py-6"> 

				<div class="col-lg-10 mx-auto">

			<!-- start :: blog content -->
			<div class="section">
				<div class="container"> 

					<div class="row g-xl-5">

						<div class="col-lg-9 order-2 order-lg-1">

					<div id="logbook" class="article-format">


						<h2>LOGBOOK SEBAGAI PERSYARATAN KENAIKAN JENJANG KARIR DI RUMAH SAKIT</h2>
						<p>
Penggunaan logbook terbukti bermanfaat sebagai alat monitoring dan evaluasi pelaksanaan kompetensi klinis dan alat pertanggungjawaban terhadap penugasan klinis yang diberikan kepadanya. logbook merupakan alat penting karena bermanfaat sebagai bukti rekam bahwa tenaga kesehatan telah melaksanakan tindakan sesuai dengan kewenangannya. Hal ini diperkuat dengan PMK Nomor 49 tahun 2013 tentang komite keperawatan, bahwa logbook kompetensi perawat yang telah disusun oleh bagian sub kredensial dijadikan salah satu syarat perawat dalam mengajukan proses kredensial.
						</p>
						<p><h5 class="blinking">
							DATA PROGRAM HANYA UNTUK SAMPLE SEHINGGA TIDAK DAPAT DI TAMBAH HANYA SEBAGAI DISPLAY UNTUK MEMAHAMI ALUR DI PROGRAM ASLINYA
						</h5></p>

					</div>

							<div class="mb-4">
								<h1 class="h3 mb-0">
									KEWENANGAN SESUAI PROFESI
								</h1>

							</div>



							<!-- post image -->
							<figure class="d-block text-center rounded overflow-hidden mb-5">
								<img class="img-fluid rounded" src="<?php echo base_url();?>assets/images/manifest/logbook.png" alt="...">
							</figure>



							<!--
								.article-format class will add some slightly formattings for a good text visuals. 
								This is because most editors are not ready formatted for bootstrap
								Blog content should come inside this container, as it is from database!
								src/scss/_core/base/_typography.scss
							-->
							<div class="article-format">

								<p>
Logbook berisi butir kegiatan sesuai dengan profesi / jabatan fungsionalnya, di bawah ini adalah salah satu contoh pengisian logbook dan karena di dalam sample ini tidak ada Signin dan Signup maka akan di tampilkan kewenangan semua profesi
								</p>
									<a href="<?php echo base_url();?>s_logbook/logbook" style="color: black;font-weight: bold;" class="btn w-100 btn-md btn-info bg-gradient-info">
										Pengisian Logbook
									</a>
							</div>

							<hr>
					<div id="pengajuan" class="article-format">


						<h2>PENGAJUAN KOMPETENSI</h2>
						<p>
Setelah logbook dibuat, maka dapat di ajukan pengajuan kompetensi / kredensial suatu saat nanti. Jangan lupa untuk selalu mengupload / update berkas, biodata dan lain-lain.
						</p>
						<p>
Pengajuan Kompetensi merupakan ujian tertulis untuk mengetahui dan menguji pengetahuan, keterampilan, serta sikap dalam menjalankan tugasnya sebagai tenaga medis, untuk itu sebelum dilakukan pengajuan maka dipersiapkan etik oleh kepala ruangan sebagai salah satu syarat pengajuan kompetensi
						</p>

					</div>
					
							<div class="mb-4">
								<h1 class="h3 mb-0">
									
								</h1>

							</div>



							<!-- post image -->
							<figure class="d-block text-center rounded overflow-hidden mb-5">
								<img class="img-fluid rounded" src="<?php echo base_url();?>assets/images/manifest/pengajuan.png" alt="...">
							</figure>



							<!--
								.article-format class will add some slightly formattings for a good text visuals. 
								This is because most editors are not ready formatted for bootstrap
								Blog content should come inside this container, as it is from database!
								src/scss/_core/base/_typography.scss
							-->
							<div class="article-format">

								<p>
Kategori pengajuan di antaranya Kenaikan Tingkat, Kredensial, Penambahan Kewenangan, Pemulihan Kewenangan. Ajukan kompetensi dengan mengumpulkan berkas surat ijin yang berlaku, etik yang berlaku (sudah di dalam program), sertifikat terbaru dan ijasah terakhir.
								</p>
								
								<p>
Setelah terkumpul maka kirim datanya dengan klik Kirim Data untuk proses selanjutnya
								</p>

									<a href="<?php echo base_url();?>s_pengajuan/pengajuan_kompetensi" style="color: black;font-weight: bold;" class="btn w-100 btn-md btn-info bg-gradient-info">
										Pengajuan Kompetensi
									</a>
							</div>

							<hr>
					<div id="validasi" class="article-format">


						<h2>VALIDASI KOMPETENSI</h2>
						<p>
Setelah data terkirim, hubungi admin untuk di proses dan dibentuk team. Di dalam program nantinya akan dipilih siapa saja yang akan menguji sesuai dengan jenis validatornya, misalkan kepala ruangan, kepala bidang, asesor, komite, tim bestari dan semua validator ini bisa berbeda di tiap instansi
						</p>
						<p>
Apabila terbentuk maka dapat di adakan pengujian kompetensi, masing-masing validator dapat melakukan pengujian melalui program sesuai dengan pola dan metode masing-masing.
						</p>
						<p>
Lakukan validasi apakah setuju atau ditolak (supervisi atau tidak kompeten), kelanjutan dari ditolak adalah data tidak akan muncul di pengujian berikutnya sehingga nantinya akan dilakukan pemulihan kewenangan dikemudian hari.
						</p>
					</div>
					
							<div class="mb-4">
								<h1 class="h3 mb-0">
									
								</h1>

							</div>



							<!-- post image -->
							<figure class="d-block text-center rounded overflow-hidden mb-5">
								<img class="img-fluid rounded" src="<?php echo base_url();?>assets/images/manifest/pengajuan.png" alt="...">
							</figure>



							<!--
								.article-format class will add some slightly formattings for a good text visuals. 
								This is because most editors are not ready formatted for bootstrap
								Blog content should come inside this container, as it is from database!
								src/scss/_core/base/_typography.scss
							-->
							<div class="article-format">

									<a href="<?php echo base_url();?>s_kompetensi/pengajuan_kompetensi" style="color: black;font-weight: bold;" class="btn w-100 btn-md btn-info bg-gradient-info">
										Validasi Kompetensi
									</a>
							</div>

							<hr>
					<div id="spk" class="article-format">


						<h2>PENERBITAN PENUGASAN KLINIS</h2>
						<p>
Jika semua sudah teruji, maka dilanjutkan upload data hasil pengujian mutu, etika, kredensial dan rekomendasi sehingga dapat di terbitkan penugasan klinis.
						</p>

					</div>
					
							<div class="mb-4">
								<h1 class="h3 mb-0">
									
								</h1>

							</div>



							<!-- post image -->
							<figure class="d-block text-center rounded overflow-hidden mb-5">
								<img class="img-fluid rounded" src="<?php echo base_url();?>assets/images/manifest/spk.png" alt="...">
							</figure>



							<!--
								.article-format class will add some slightly formattings for a good text visuals. 
								This is because most editors are not ready formatted for bootstrap
								Blog content should come inside this container, as it is from database!
								src/scss/_core/base/_typography.scss
							-->
							<div class="article-format">

								<p>
Kategori pengajuan di antaranya Kenaikan Tingkat, Kredensial, Penambahan Kewenangan, Pemulihan Kewenangan
								</p>
									<a href="<?php echo base_url();?>spk" style="color: black;font-weight: bold;" class="btn w-100 btn-md btn-info bg-gradient-info">
										Penugasan Klinis
									</a>
							</div>							

						</div>

						<div class="col-lg-3 order-1 order-lg-2 mb-5">

							<!-- CATEGORIES -->
							<nav class="nav-deep nav-deep-light mb-2">

								<!-- mobile only -->
								<button class="clearfix btn btn-toggle btn-sm w-100 text-align-left shadow-md border rounded mb-1 d-block d-lg-none" data-bs-target="#nav_responsive" data-toggle-container-class="d-none d-sm-block bg-white shadow-md border animate-fadein rounded p-3">
									<span class="group-icon px-2 py-2 float-start">
										<i class="fi fi-bars-2"></i>
										<i class="fi fi-close"></i>
									</span>

									<span class="h5 py-2 m-0 float-start">
										Kategori
									</span>
								</button>

								<!-- desktop only -->
								<h3 class="h5 py-3 m-0 d-none d-lg-block">
									Kategori
								</h3>


								<!-- navbar : navigation -->
								<ul id="nav_responsive" class="nav flex-column d-none d-lg-block">
									<li class="nav-item">
										<a class="nav-link" href="#logbook">
										 	Logbook
										</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#pengajuan">
											Pengajuan Kompetensi
										</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#validasi">
											Validasi
										</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="#spk">
											Surat Penugasan Klinis
										</a>
									</li>
								</ul>

							</nav>
							<!-- /CATEGORIES -->


						</div>

					</div>

				</div>
			</div>	
			<!-- end :: blog content -->

				</div>

			</div>
			<!-- end :: blog content -->
<?php
}
