<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description"
    content="Multipurpose, super flexible, powerful, clean modern responsive bootstrap 5 admin template">
  <meta name="keywords"
    content="admin template, ra-admin admin template, dashboard template, flat admin template, responsive admin template, web app">
  <meta name="author" content="la-themes">
  <link rel="icon" href="<?= base_url() ?>assets/images/favicon.ico" type="image/x-icon">
  <link rel="shortcut icon" href="<?= base_url() ?>assets/images/favicon.ico" type="image/x-icon">

  <title><?php echo $header; ?> | <?php echo $instance_name; ?></title>

  <link rel="stylesheet" href="<?= base_url() ?>rassets/vendor/fontawesome/css/all.css">

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Golos+Text:wght@400..900&display=swap" rel="stylesheet">


  <!-- Data Table css-->
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/datatable/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/datatable/select.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/datatable/buttons.dataTables.min.css">
  <!--<link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/datatable/datatable-loader.css">-->

  <!-- tabler icons-->
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/tabler-icons/tabler-icons.css">

  <!--flag Icon css-->
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/flag-icons-master/flag-icon.css">

  <!-- Bootstrap css-->
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/bootstrap/bootstrap.min.css">

  <!-- simplebar css-->
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/vendor/simplebar/simplebar.css">

  <!-- Toatify css-->
  <link rel="stylesheet" href="<?= base_url() ?>rassets/vendor/notifications/toastify.min.css">

  <!-- App css-->
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/css/style.css">

  <!-- Responsive css-->
  <link rel="stylesheet" type="text/css" href="<?= base_url() ?>rassets/css/responsive.css">
  <style>
  .blinking {
    animation: opacity 2s ease-in-out infinite;
    opacity: 1;
  }
  @keyframes opacity {
    0% {
    opacity: 1;
    }

    50% {
    opacity: 0.5;
    }

    100% {
    opacity: 0;
    }
  }
/* ======================================================
   DATATABLE BUTTONS & SELECT – STABLE VERSION
   CI3 + Bootstrap 4/5 SAFE
   ====================================================== */

/* ---------- SELECTED ROW ---------- */
table.dataTable tbody tr.selected {
    background-color: rgba(85,110,230,.18) !important;
}
table.dataTable tbody tr.selected td,
table.dataTable tbody tr.selected th {
    color:#212529 !important;
    font-weight:500;
}
table.dataTable tbody tr.selected:hover {
    background-color: rgba(85,110,230,.28) !important;
}

/* ---------- CHECKBOX SELECT ---------- */
td.select-checkbox::before {
    content:"☐";
    color:#adb5bd;
    font-size:14px;
}
tr.selected td.select-checkbox::before {
    content:"☑";
    color:#556ee6;
    font-weight:bold;
}

/* ---------- WRAPPER SAFETY ---------- */
/*.card,
.card-body,
.dataTables_wrapper,
.app-datatable-default {
    overflow: visible !important;
}*/
.dataTables_wrapper {
    overflow-x: auto;
}
.dataTables_wrapper .dt-buttons {
    justify-content: center;
    display: flex;
    align-items: center;
    gap: 6px;

    margin-left: 16px;   /* ⬅️ INI KUNCINYA */
    margin-bottom: 8px;
}

/* ---------- BUTTONS CONTAINER ---------- */
.dt-buttons-wrap {
    padding-left: 12px;      /* geser dari kiri */
    padding-top: 4px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.dt-buttons {
    float: none !important;
    position:relative;
    z-index:20;
}

/* ---------- CORE BUTTON ---------- */
.dt-buttons .btn {
    display:inline-flex !important;
    align-items:center;
    gap:6px;

    height:32px;
    padding: 4px 10px !important;
    font-size:11.5px !important;
    font-weight:500;

    border-radius:7px !important;
    border:1px solid transparent !important;

    line-height:1;
    white-space:nowrap;
    cursor:pointer;

    transition:all .15s ease;
    pointer-events:auto !important;
}

/* ---------- ICON BUTTON ---------- */
.dt-buttons .btn-icon {
    width:32px !important;
    height:32px !important;
    padding:0 !important;
    justify-content:center;
    border-radius:50% !important;
}

/* ---------- HOVER ---------- */
.dt-buttons .btn:hover {
    filter:brightness(.95);
}

/* ---------- COLOR THEMES ---------- */
.dt-buttons .btn-primary   {background:#5ccad6!important;color:#fff!important;}
.dt-buttons .btn-secondary {background:#8b8378!important;color:#fff!important;}
.dt-buttons .btn-success   {background:#b6d91d!important;color:#fff!important;}
.dt-buttons .btn-danger    {background:#ff6b45!important;color:#fff!important;}
.dt-buttons .btn-warning   {background:#f3c742!important;color:#212529!important;}
.dt-buttons .btn-info      {background:#5a63f2!important;color:#fff!important;}
.dt-buttons .btn-light     {background:#e6e3df!important;color:#212529!important;}
.dt-buttons .btn-dark      {background:#3f3b36!important;color:#fff!important;}

/* ---------- OUTLINE ---------- */
.dt-buttons .btn-outline-primary   {color:#5ccad6!important;border-color:#5ccad6!important;}
.dt-buttons .btn-outline-secondary {color:#8b8378!important;border-color:#8b8378!important;}
.dt-buttons .btn-outline-success   {color:#b6d91d!important;border-color:#b6d91d!important;}
.dt-buttons .btn-outline-danger    {color:#ff6b45!important;border-color:#ff6b45!important;}
.dt-buttons .btn-outline-warning   {color:#f3c742!important;border-color:#f3c742!important;}
.dt-buttons .btn-outline-info      {color:#5a63f2!important;border-color:#5a63f2!important;}
.dt-buttons .btn-outline-dark      {color:#3f3b36!important;border-color:#3f3b36!important;}

/* ---------- PASTEL ---------- */
.dt-buttons .btn-pastel {border:none!important;}
.dt-buttons .btn-pastel-primary   {background:#e6f8fb!important;color:#2ec7d3!important;}
.dt-buttons .btn-pastel-secondary {background:#f1ede8!important;color:#8c7b6a!important;}
.dt-buttons .btn-pastel-success   {background:#f0f9e6!important;color:#9acd32!important;}
.dt-buttons .btn-pastel-danger    {background:#ffece6!important;color:#ff5733!important;}
.dt-buttons .btn-pastel-warning   {background:#fff6db!important;color:#f2b705!important;}
.dt-buttons .btn-pastel-info      {background:#eef0ff!important;color:#5864ff!important;}

/* ===== SHAPES ===== */
.btn-pill       { border-radius:999px!important; }
.btn-square     { border-radius:0!important; }
.btn-rounded-sm { border-radius:4px!important; }
.btn-rounded-lg { border-radius:12px!important; }

/* ===== SIZE ===== */
.btn-xs { height:26px!important;font-size:10px!important;padding:2px 8px!important; }
.btn-md { height:36px!important;font-size:12px!important;padding:6px 12px!important; }

/* ===== EFFECTS ===== */
.btn-soft-shadow { box-shadow:0 4px 10px rgba(0,0,0,.15)!important; }
.btn-glow {
    box-shadow:0 0 0 rgba(0,0,0,0);
    animation: glowPulse 2s infinite;
}
@keyframes glowPulse {
    0%   { box-shadow:0 0 0 rgba(0,0,0,0); }
    50%  { box-shadow:0 0 12px rgba(90,99,242,.6); }
    100% { box-shadow:0 0 0 rgba(0,0,0,0); }
}

.btn-ghost {
    background:transparent!important;
    border-style:dashed!important;
}

/* ---------- DROPDOWN (COLVIS / EXPORT) ---------- */
.dt-button-collection {
    padding:8px !important;
    z-index:9999 !important;
}
.dt-button-collection .dt-button {
    display:block;
    width:100%;
    text-align:left;
    margin-bottom:4px;
    color:#212529!important;
    background:#fff!important;
}
.dt-button-collection .dt-button.active {
    background:#556ee6!important;
    color:#fff!important;
}
/* ===============================
   FIX DATATABLE ROW SELECTED
   =============================== */

table.dataTable tbody tr.selected,
table.dataTable tbody tr.selected > td {
    background-color: #0d6efd !important; /* biru */
    color: #fff !important;
}

/* hover saat selected */
table.dataTable tbody tr.selected:hover,
table.dataTable tbody tr.selected:hover > td {
    background-color: #0b5ed7 !important;
}

/* hilangkan efek striped yang nabrak */
table.dataTable.table-striped tbody tr.selected:nth-of-type(odd),
table.dataTable.table-striped tbody tr.selected:nth-of-type(even) {
    background-color: #0d6efd !important;
}
table.dataTable tbody tr.selected td.dt-control {
    background-color: #0d6efd !important;
}
table.dataTable tbody tr.selected td {
    border-color: rgba(255,255,255,.2);
}

/* ---------- MOBILE ---------- */
@media (max-width:768px){
    .dt-buttons .btn {
        font-size:11px!important;
        padding:4px 8px!important;
    }
}
td.dt-control {
    cursor: pointer;
    text-align: center;
}

td.dt-control:before {
    content: "+";
    background: #0d6efd;
    color: #fff;
    padding: 3px 8px;
    border-radius: 4px;
}

tr.shown td.dt-control:before {
    content: "-";
}
tr.shown + tr td table tbody tr:hover {
    background-color: #f1f5ff !important;
    cursor: pointer;
}
/* ===== DARK MODE AUTO ===== */
@media (prefers-color-scheme: dark) {
    .dt-buttons .btn-pastel {
        filter:brightness(.9);
    }
}
/* ===============================
   SIDEBAR SUPER COMPACT
================================ */

.vertical-sidebar .main-nav li > a{
  font-size: 11px !important;
  line-height: 1.15 !important;
}

.vertical-sidebar .main-nav > li > a{
  font-size: 11px !important;
  font-weight: 500 !important;
}

  </style>
</head>

<body text="small-text">
  <!-- ganti customizer
    <body class="box-layout" text="large-text">
    <body class="rtl light" text="medium-text">
    <body class="ltr dark" text="small-text">
    -->
<?php
	$array = array('hot','gold','happy','warm','default');
	$k = array_rand($array);
	$v = $array[$k];
?>
  <div class="app-wrapper <?= $v ?>" text="small-text">
  <!-- ganti customizer
    <div class="app-wrapper hot" text="large-text">
    <div class="app-wrapper gold" text="medium-text">
    <div class="app-wrapper happy" text="small-text">
    <div class="app-wrapper warm" text="small-text">
    <div class="app-wrapper default" text="small-text">
    -->
    <div class="loader-wrapper">
      <div class="app-loader">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
<?php
 $array = array('green','blue','yellow','red','purple');
 $k = array_rand($array);
 $v = $array[$k]; 
if(empty($photo)){
 $url_thumb=base_url().'assets/images/noavatar.jpg';
 $url_picbesar=base_url().'assets/images/noavatar.jpg';    
}else{
 $cek_filesmall=FCPATH.'assets/foto/ol/'.$photo;
 if(file_exists($cek_filesmall)){
  $url_thumb=base_url().'assets/foto/ol/'.$photo;
  $url_picbesar=base_url().'assets/foto/ol/'.$photo;
 }else{
  $url_thumb=base_url().'assets/images/noavatar.jpg';
  $url_picbesar=base_url().'assets/images/noavatar.jpg';
 }    
}
function cek_aktif($page,$alamat) 
{
  $status=FALSE;
  if (is_array($alamat)){
    foreach ($alamat as $d) {
      if($page==$d) 
        $status=TRUE; 
    }
  }
  else{
    if($page==$alamat) 
      $status=TRUE; 
  }
  if($status) 
    echo "active";
  else
    echo "" ;
}
?>
  <!-- ganti customizer
    <nav class="selected vertical-sidebar">
    <nav class="selected horizontal-sidebar">
    <nav class="selected dark-sidebar">
    -->
    <nav class="horizontal-sidebar text-secondary small-text">
      <div class="app-logo">
        <a class="logo d-inline-block text-center" style="font-size: 1.3em;font-weight: bold;" href="<?= base_url($this->session->beranda) ?>">
          <i class="ti ti-brand-kickstarter"></i> KREDENSIAL.COM
        </a>
        <span class="bg-light-primary toggle-semi-nav">
          <i class="ti ti-chevrons-right f-s-20"></i>
        </span> 
      </div>
      <div class="app-nav" id="app-simple-bar">
<ul class="main-nav p-0 mt-2">

<?php foreach ($menu as $m): ?>

    <?php if ($m['type'] === 'parent'): ?>
        <li>
            <a href="#<?= $m['id'] ?>"
               data-bs-toggle="collapse"
               aria-expanded="false">

                <?php if (!empty($m['icon'])): ?>
                    <i class="<?= $m['icon'] ?>"></i>
                <?php endif; ?>

                <?= $m['label'] ?>
            </a>

            <ul class="collapse" id="<?= $m['id'] ?>">
                <?php foreach ($m['children'] as $c): ?>
                    <li>
                        <a href="<?= base_url($c['url']) ?>" class="menu-link">
                            <?= $c['label'] ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </li>
    <?php endif; ?>

<?php endforeach; ?>

</ul>

      </div>

      <div class="menu-navs">
      <!--  <span class="menu-previous"><i class="ti ti-chevron-left"></i></span>
        <span class="menu-next"><i class="ti ti-chevron-right"></i></span>-->
      </div>

    </nav>

    <div class="app-content">
      <div class="">

        <header class="header-main">
          <div class="container-fluid">
            <div class="row">
              <div class="col-6 col-sm-4 d-flex align-items-center header-left p-0">
                <span class="header-toggle me-3">
                  <i class="ph ph-circles-four"></i>
                </span>
              </div>
              <div class="col-6 col-sm-8 d-flex align-items-center justify-content-end header-right p-0">
                <ul class="d-flex align-items-center">
                  <li class="header-cloud">
                    <div class="head-icon" id="timer_waktu" style="font-size: 1em;"></div>
                  </li>
                  <li class="header-cloud">
                    <div class="head-icon" style="font-size: 1em;">
                    <SCRIPT language=JavaScript>var d = new Date();
                      var h = d.getHours();
                      if (h < 11) { document.write('SELAMAT PAGI '); }
                      else { if (h < 15) { document.write('SELAMAT SIANG '); }
                      else { if (h < 19) { document.write('SELAMAT SORE '); }
                      else { if (h <= 23) { document.write('SELAMAT MALAM '); }
                      }}}
                    </SCRIPT>
                    </div>
                  </li>
                  <li class="header-profile">
                    <a href="#" class="d-block head-icon" role="button" data-bs-toggle="offcanvas"
                       data-bs-target="#profilecanvasRight" aria-controls="profilecanvasRight">
                      <img src="<?= $url_thumb ?>" alt="avtar" class="b-r-10 h-35 w-35">
                    </a>

                   <div class="offcanvas offcanvas-end header-profile-canvas" tabindex="-1" id="profilecanvasRight"
                         aria-labelledby="profilecanvasRight">
                      <div class="offcanvas-body app-scroll">
                        <ul class="">
                          <li>
                            <div class="d-flex-center">
                              <span class="h-45 w-45 d-flex-center b-r-10 position-relative">
                                <img src="<?= $url_thumb ?>" alt="" class="img-fluid b-r-10">
                              </span>
                            </div>
                            <div class="text-center mt-2">
                              <h6 class="mb-0"> <?= $member_name ?></h6>
                              <p class="f-s-12 mb-0 text-secondary">ANGGOTA</p>
                            </div>
                          </li>

                          <li class="app-divider-v dotted py-1"></li>
                          <li>
                            <a class="f-w-500" href="<?= base_url('member/profil') ?>">
                              <i class="ph-duotone  ph-user-circle pe-1 f-s-20"></i> Profile Details
                            </a>
                          </li>
                          <li class="app-divider-v dotted py-1"></li>
                          <li>
                            <a class="mb-0 text-danger" href="<?= base_url('logout') ?>">
                              <i class="ph-duotone  ph-sign-out pe-1 f-s-20"></i> Log Out
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </header>